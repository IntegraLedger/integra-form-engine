# Integra Ledger — Trust Badge, QR Attestation & Certificate System

## Context
This project was developed across two Claude.ai conversations on 2026-02-12.
The transcripts in `transcripts/` contain the full conversation history.

## What's Here

### code/
- **integra.js** — Main embeddable script. Trust badge, form attestation, QR code generation, analytics beacon. Drop-in `<script>` tag for any website.
- **integra_cert.py** — PDF certificate generator with per-field salted HMAC-SHA256 hashes, Merkle root, QR code, selective disclosure support.
- **morph-demo.html** — Interactive demo: badge morphs from static shield → animated QR on form submit (canvas particle system).
- **demo-form.html** — Full flow demo: form → attestation → QR badge update → receipt with verification link.
- **demo.html** — Basic badge embed demo.
- **badge.js** — Standalone badge component (predecessor to integra.js).
- **ask-integra.js** — Earlier iteration of the main script.
- **extension/** — Chrome extension: Integra Badge Validator. Detects badges, validates against API, checks domain ownership.
- **integra-badge-validator-extension.zip** — Packaged extension ready for Chrome Web Store.

### transcripts/
- **journal.txt** — Index of all conversation transcripts.
- **2026-02-12-20-03-23-integra-badge-zendesk-webhooks.txt** — Session 1: Badge design, form attestation widget, Zendesk/DocuSign webhook integration, analytics.
- **2026-02-12-20-18-40-qr-badge-mobile-app-integration.txt** — Session 2: QR code badge, mobile app deep linking, Chrome extension, field-level hashing, PDF certificates.

## Architecture Summary

### Badge States
1. **Default:** Shield logo + site verification QR (`integra://site/{SITE_ID}`)
2. **Post-attestation:** Morphs to attestation QR (`integra://attest/{INTEGRA_ID}?h=...&m=...`)

### Crypto Model
- **Content hash:** SHA-256 of canonicalized (sorted keys) JSON form data
- **Field hashes:** HMAC-SHA256(salt, "fieldName:fieldValue") per field
- **Merkle root:** Binary tree of field hashes
- **On-chain anchor:** EAS (Ethereum Attestation Service) attestation UID

### API Endpoints (to build)
- `POST /v1/attest/form` — Create attestation, return integraId + receipt
- `GET /v1/verify/{integraId}` — Verify attestation (mobile app + web)
- `GET /v1/cert/{integraId}` — Generate/download PDF certificate
- `POST /v1/site/verify` — Validate site registration (Chrome extension)
- `GET /v1/site/domains` — Domain ownership check
- `POST /v1/badge/log` — Analytics beacon
- `POST /v1/webhooks/zendesk` — Zendesk ticket webhook
- `POST /v1/webhooks/docusign` — DocuSign envelope webhook

### Integration Points
- **Zendesk:** Custom ticket field injection via widget API + server webhook
- **DocuSign:** Envelope completion webhook → attestation
- **Mobile app:** QR scanner + `integra://` deep link handler
- **Chrome extension:** Automatic badge detection + validation

## Next Steps
See transcripts for full discussion. Key todos:
- Build API server (Supabase + Edge Functions or Cloudflare Workers)
- Mobile app with QR scanner + deep link handler
- Embed qrcode-generator in integra.js (remove external API dependency)
- EAS on-chain anchoring integration
- Zendesk custom field injection logic
- Chrome Web Store submission
