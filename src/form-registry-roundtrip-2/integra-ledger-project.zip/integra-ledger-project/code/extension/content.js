/**
 * Ask Integra - Content Script
 * Scans every page for Integra presence and validates it
 */
(function () {
  "use strict";

  const API_BASE = "https://api.integraledger.com/v1";

  // ─── Detection: find all Integra signals on the page ──────────
  function detectIntegraPresence() {
    const signals = {
      badge: null,
      script: null,
      metaTags: [],
      hiddenFields: [],
      jsonLd: [],
      windowApi: false,
      attestations: [],
    };

    // 1. Badge element
    const badge = document.getElementById("integra-badge");
    if (badge) {
      signals.badge = {
        found: true,
        href: badge.href || null,
        position: badge.style.position,
      };
    }

    // 2. Integra script include
    const scripts = document.querySelectorAll("script[src]");
    scripts.forEach((s) => {
      if (s.src.includes("integra")) {
        signals.script = {
          found: true,
          src: s.src,
          siteId: s.getAttribute("data-integra-id") || null,
          hasApiKey: !!s.getAttribute("data-integra-key"),
        };
      }
    });

    // 3. Meta tags
    document.querySelectorAll('meta[name^="integra:"]').forEach((m) => {
      signals.metaTags.push({
        name: m.getAttribute("name"),
        content: m.getAttribute("content"),
      });
    });

    // 4. Hidden form fields
    document.querySelectorAll('input[name="integraId"], input[name="integraHash"]').forEach((el) => {
      signals.hiddenFields.push({
        name: el.name,
        value: el.value,
        formId: el.form?.id || null,
      });
    });

    // 5. Forms with attestation enabled
    document.querySelectorAll('form[data-integra-attest="true"]').forEach((form) => {
      signals.attestations.push({
        formId: form.id || null,
        formLabel: form.dataset.integraLabel || form.id || "Unknown",
        mode: form.dataset.integraMode || "native",
        action: form.action || null,
      });
    });

    // 6. JSON-LD attestation data
    document.querySelectorAll('script[type="application/ld+json"]').forEach((s) => {
      try {
        const data = JSON.parse(s.textContent);
        const items = Array.isArray(data) ? data : [data];
        items.forEach((item) => {
          if (
            item["@type"] === "IntegraAttestation" ||
            item["@type"] === "BlockchainAttestation" ||
            item["@type"] === "DocumentVerification"
          ) {
            signals.jsonLd.push(item);
          }
        });
      } catch (e) {}
    });

    // 7. Window API
    if (window.Integra || window.IntegraAttestation) {
      signals.windowApi = true;
    }

    return signals;
  }

  // ─── Validation: check signals against the API ────────────────
  async function validateSignals(signals) {
    const results = {
      status: "none", // none, valid, invalid, partial, error
      siteId: signals.script?.siteId || null,
      checks: [],
    };

    // Check 1: Is the script loaded from official CDN?
    if (signals.script) {
      const isOfficial =
        signals.script.src.includes("cdn.integraledger.com") ||
        signals.script.src.includes("integraledger.com");
      results.checks.push({
        name: "Script Source",
        status: isOfficial ? "pass" : "warn",
        detail: isOfficial
          ? `Loaded from ${new URL(signals.script.src).hostname}`
          : `Non-standard source: ${signals.script.src}`,
      });
    }

    // Check 2: Does the site have a valid registration?
    if (signals.script?.siteId) {
      try {
        const res = await fetch(`${API_BASE}/site/verify`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            siteId: signals.script.siteId,
            origin: window.location.origin,
          }),
        });

        if (res.ok) {
          const data = await res.json();
          results.checks.push({
            name: "Site Registration",
            status: data.verified ? "pass" : "fail",
            detail: data.verified
              ? `Registered: ${data.organizationName || signals.script.siteId}`
              : "Site ID not found in Integra registry",
            data,
          });
        } else {
          results.checks.push({
            name: "Site Registration",
            status: "error",
            detail: `API returned ${res.status}`,
          });
        }
      } catch (err) {
        results.checks.push({
          name: "Site Registration",
          status: "error",
          detail: `Could not reach Integra API: ${err.message}`,
        });
      }
    }

    // Check 3: Domain match — is the badge on the right domain?
    if (signals.script?.siteId) {
      try {
        const res = await fetch(`${API_BASE}/site/domains`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ siteId: signals.script.siteId }),
        });

        if (res.ok) {
          const data = await res.json();
          const currentDomain = window.location.hostname;
          const match = data.domains?.some(
            (d) => currentDomain === d || currentDomain.endsWith(`.${d}`)
          );
          results.checks.push({
            name: "Domain Match",
            status: match ? "pass" : "fail",
            detail: match
              ? `${currentDomain} is registered for this site ID`
              : `${currentDomain} is NOT registered — possible badge theft`,
          });
        }
      } catch (err) {
        results.checks.push({
          name: "Domain Match",
          status: "error",
          detail: "Could not verify domain",
        });
      }
    }

    // Check 4: SSL certificate status
    results.checks.push({
      name: "SSL/TLS",
      status: window.location.protocol === "https:" ? "pass" : "fail",
      detail:
        window.location.protocol === "https:"
          ? "Page served over HTTPS"
          : "Page is NOT using HTTPS — attestations may not be trustworthy",
    });

    // Check 5: Any attestation records on this page?
    const attestationCount =
      signals.hiddenFields.filter((f) => f.name === "integraId" && f.value).length +
      signals.jsonLd.length +
      signals.metaTags.filter((m) => m.name === "integra:attestation").length;

    if (attestationCount > 0) {
      results.checks.push({
        name: "Attestation Records",
        status: "pass",
        detail: `${attestationCount} attestation(s) found on this page`,
      });
    }

    // Check 6: Form attestation enabled?
    if (signals.attestations.length > 0) {
      results.checks.push({
        name: "Form Attestation",
        status: "pass",
        detail: `${signals.attestations.length} form(s) with attestation enabled`,
      });
    }

    // Compute overall status
    const statuses = results.checks.map((c) => c.status);
    if (statuses.includes("fail")) {
      results.status = "invalid";
    } else if (statuses.every((s) => s === "pass")) {
      results.status = "valid";
    } else if (statuses.includes("pass")) {
      results.status = "partial";
    } else if (statuses.includes("error")) {
      results.status = "error";
    }

    return results;
  }

  // ─── Notify extension ─────────────────────────────────────────
  async function run() {
    const signals = detectIntegraPresence();
    const hasIntegra =
      signals.badge ||
      signals.script ||
      signals.metaTags.length > 0 ||
      signals.hiddenFields.length > 0 ||
      signals.jsonLd.length > 0 ||
      signals.windowApi ||
      signals.attestations.length > 0;

    if (!hasIntegra) {
      // No Integra presence — tell the popup
      chrome.runtime.sendMessage({
        type: "integra:scan",
        found: false,
        url: window.location.href,
      });
      return;
    }

    // Validate
    const validation = await validateSignals(signals);

    chrome.runtime.sendMessage({
      type: "integra:scan",
      found: true,
      url: window.location.href,
      signals,
      validation,
    });
  }

  // Listen for popup requesting a scan
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "integra:requestScan") {
      run().then(() => sendResponse({ ok: true }));
      return true; // async
    }
  });

  // Auto-scan on load
  run();
})();
