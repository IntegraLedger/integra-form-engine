/**
 * Background service worker
 * Updates extension icon based on Integra badge scan results
 */

// Store last scan results per tab
const tabResults = {};

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type !== "integra:scan") return;

  const tabId = sender.tab?.id;
  if (!tabId) return;

  tabResults[tabId] = msg;

  if (!msg.found) {
    // No Integra presence — grey icon
    chrome.action.setIcon({
      tabId,
      path: {
        16: "icons/icon16-grey.png",
        48: "icons/icon48-grey.png",
      },
    }).catch(() => {});
    chrome.action.setBadgeText({ tabId, text: "" });
    return;
  }

  const status = msg.validation?.status;

  if (status === "valid") {
    // Green badge
    chrome.action.setIcon({
      tabId,
      path: { 16: "icons/icon16.png", 48: "icons/icon48.png" },
    }).catch(() => {});
    chrome.action.setBadgeText({ tabId, text: "✓" });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#16a34a" });
  } else if (status === "invalid") {
    // Red badge
    chrome.action.setIcon({
      tabId,
      path: { 16: "icons/icon16-red.png", 48: "icons/icon48-red.png" },
    }).catch(() => {});
    chrome.action.setBadgeText({ tabId, text: "✗" });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#dc2626" });
  } else if (status === "partial" || status === "error") {
    // Yellow badge
    chrome.action.setIcon({
      tabId,
      path: { 16: "icons/icon16.png", 48: "icons/icon48.png" },
    }).catch(() => {});
    chrome.action.setBadgeText({ tabId, text: "?" });
    chrome.action.setBadgeBackgroundColor({ tabId, color: "#f59e0b" });
  }
});

// Clean up on tab close
chrome.tabs.onRemoved.addListener((tabId) => {
  delete tabResults[tabId];
});

// Serve results to popup
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "integra:getResults") {
    sendResponse(tabResults[msg.tabId] || null);
  }
});
