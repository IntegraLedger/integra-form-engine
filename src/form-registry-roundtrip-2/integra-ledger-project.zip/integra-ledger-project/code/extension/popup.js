/**
 * Popup script - fetches scan results and renders them
 */
(function () {
  const content = document.getElementById("content");

  const STATUS_MAP = {
    valid:   { label: "Verified Integra Badge", class: "valid",   dot: "green" },
    invalid: { label: "Invalid or Stolen Badge", class: "invalid", dot: "red" },
    partial: { label: "Partially Verified",      class: "partial", dot: "yellow" },
    error:   { label: "Verification Error",      class: "error",   dot: "yellow" },
    none:    { label: "No Integra Badge Found",  class: "none",    dot: "grey" },
  };

  const CHECK_ICONS = {
    pass: "✅",
    fail: "❌",
    warn: "⚠️",
    error: "⚙️",
  };

  function render(data) {
    if (!data || !data.found) {
      content.innerHTML = `
        <div class="status-bar none">
          <span class="dot grey"></span>
          No Integra Badge Detected
        </div>
        <div class="empty">
          <p>This page does not have an Integra trust badge, attestation-enabled forms, or any Integra metadata.</p>
        </div>
      `;
      return;
    }

    const v = data.validation || {};
    const s = STATUS_MAP[v.status] || STATUS_MAP.none;

    let checksHtml = "";
    if (v.checks?.length) {
      checksHtml = `<div class="checks">` +
        v.checks.map((c) => `
          <div class="check">
            <span class="check-icon">${CHECK_ICONS[c.status] || "•"}</span>
            <div>
              <div class="check-name">${esc(c.name)}</div>
              <div class="check-detail">${esc(c.detail)}</div>
            </div>
          </div>
        `).join("") +
        `</div>`;
    }

    let infoHtml = "";
    const sig = data.signals || {};
    const rows = [];
    if (sig.script?.siteId) rows.push(["Site ID", sig.script.siteId]);
    if (sig.script?.src)    rows.push(["Script", new URL(sig.script.src).hostname]);
    if (sig.attestations?.length) rows.push(["Attested Forms", sig.attestations.length]);
    if (sig.hiddenFields?.length) rows.push(["Attestation Fields", sig.hiddenFields.length]);
    if (sig.metaTags?.length)     rows.push(["Meta Tags", sig.metaTags.length]);

    if (rows.length) {
      infoHtml = `<div class="info-section">` +
        rows.map(([k, v]) => `
          <div class="info-row">
            <span class="info-label">${esc(k)}</span>
            <span class="info-value">${esc(String(v))}</span>
          </div>
        `).join("") +
        `</div>`;
    }

    content.innerHTML = `
      <div class="status-bar ${s.class}">
        <span class="dot ${s.dot}"></span>
        ${esc(s.label)}
      </div>
      ${checksHtml}
      ${infoHtml}
    `;
  }

  function esc(str) {
    const el = document.createElement("span");
    el.textContent = str;
    return el.innerHTML;
  }

  // ─── Load results ─────────────────────────────────────────────
  async function loadResults() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;

    // Ask background for cached results
    chrome.runtime.sendMessage(
      { type: "integra:getResults", tabId: tab.id },
      (result) => {
        if (result) {
          render(result);
        } else {
          // Trigger a new scan
          chrome.tabs.sendMessage(tab.id, { type: "integra:requestScan" });
          // Listen for result
          chrome.runtime.onMessage.addListener(function listener(msg) {
            if (msg.type === "integra:scan") {
              chrome.runtime.onMessage.removeListener(listener);
              render(msg);
            }
          });
        }
      }
    );
  }

  // Rescan button
  document.getElementById("rescan").addEventListener("click", async () => {
    content.innerHTML = `<div class="empty"><p>Scanning...</p></div>`;
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    chrome.tabs.sendMessage(tab.id, { type: "integra:requestScan" });
    chrome.runtime.onMessage.addListener(function listener(msg) {
      if (msg.type === "integra:scan") {
        chrome.runtime.onMessage.removeListener(listener);
        render(msg);
      }
    });
  });

  loadResults();
})();
