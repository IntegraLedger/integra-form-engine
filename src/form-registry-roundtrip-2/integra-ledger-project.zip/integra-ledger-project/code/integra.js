/**
 * Ask Integra - QR Badge + Form Attestation
 *
 * The trust badge IS a QR code. Scan with Integra mobile app to:
 *   - Verify the site's registration
 *   - After form submit: verify the specific attestation
 *   - App can also re-transmit/forward the attested form data
 *
 * Usage:
 *   <script src="https://cdn.integraledger.com/integra.js"
 *           data-integra-id="SITE_ID"
 *           data-integra-key="PUBLIC_API_KEY"
 *           data-position="bottom-right"
 *           data-theme="light">
 *   </script>
 *
 *   <form data-integra-attest="true" data-integra-label="Client Intake">
 *     ...fields...
 *   </form>
 *
 * QR States:
 *   1. Default:     integra://site/{SITE_ID}?o={origin}
 *   2. Post-attest: integra://attest/{INTEGRA_ID}?h={hash}&s={siteId}&t={timestamp}
 *
 * Mobile App receives:
 *   - Deep link with integraId + content hash
 *   - App calls /v1/verify/{integraId} to get full attestation record
 *   - App can forward/share the verified attestation
 *   - App shows: form label, field names, hash, SSL cert, timestamp, verification status
 */
(function () {
  "use strict";

  const API_BASE = "https://api.integraledger.com/v1";

  const scriptTag = document.currentScript;
  const SITE_ID = scriptTag?.getAttribute("data-integra-id") || "";
  const API_KEY = scriptTag?.getAttribute("data-integra-key") || "";
  const POSITION = scriptTag?.getAttribute("data-position") || "bottom-right";
  const THEME = scriptTag?.getAttribute("data-theme") || "light";

  // ═══════════════════════════════════════════════════════════════
  // QR Code Generator (lightweight, no dependencies)
  // Generates SVG-based QR codes inline
  // ═══════════════════════════════════════════════════════════════
  const QR = (() => {
    // Minimal QR encoder — uses the QR Code API for generation
    // Falls back to a canvas-based approach
    function generateQrSvg(data, size, fgColor, bgColor) {
      // We'll use a Google Charts QR fallback for the actual encoding,
      // but render our own SVG shell for styling control.
      // For production: embed a proper QR lib like qrcode-generator.
      // For now, use an img-based approach that works everywhere.
      return null; // signals to use image approach
    }

    function generateQrImage(data, size, margin) {
      // Use a public QR API — in production, replace with embedded encoder
      const encoded = encodeURIComponent(data);
      // Using goqr.me API (free, no key needed, returns PNG)
      return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encoded}&margin=${margin}&format=svg&qzone=1`;
    }

    return { generateQrImage };
  })();

  // ═══════════════════════════════════════════════════════════════
  // Utility
  // ═══════════════════════════════════════════════════════════════
  async function sha256(str) {
    const buf = new TextEncoder().encode(str);
    const hash = await crypto.subtle.digest("SHA-256", buf);
    return Array.from(new Uint8Array(hash))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }

  function canonicalize(obj) {
    return JSON.stringify(obj, Object.keys(obj).sort());
  }

  function serializeForm(form) {
    const data = {};
    for (const [key, value] of new FormData(form).entries()) {
      if (key === "integraId" || key === "integraHash") continue;
      if (data[key]) {
        data[key] = Array.isArray(data[key]) ? [...data[key], value] : [data[key], value];
      } else {
        data[key] = value;
      }
    }
    return data;
  }

  // ═══════════════════════════════════════════════════════════════
  // API
  // ═══════════════════════════════════════════════════════════════
  async function apiCall(endpoint, payload) {
    const headers = { "Content-Type": "application/json" };
    if (API_KEY) headers["X-Integra-Key"] = API_KEY;
    const res = await fetch(`${API_BASE}${endpoint}`, {
      method: "POST",
      headers,
      body: JSON.stringify(payload),
    });
    if (!res.ok) throw new Error(`Integra API ${res.status}`);
    return res.json();
  }

  function logEvent(event, data) {
    const payload = { siteId: SITE_ID, event, url: window.location.href, timestamp: new Date().toISOString(), ...data };
    navigator.sendBeacon?.(`${API_BASE}/badge/log`, new Blob([JSON.stringify(payload)], { type: "application/json" }));
  }

  // ═══════════════════════════════════════════════════════════════
  // QR Deep Links
  // ═══════════════════════════════════════════════════════════════
  function buildSiteQrData() {
    // Default: site verification link
    // Mobile app opens this, verifies site registration
    return `integra://site/${SITE_ID}?o=${encodeURIComponent(window.location.origin)}&u=${encodeURIComponent(window.location.pathname)}`;
  }

  function buildAttestQrData(receipt) {
    // Post-attestation: specific attestation verification
    // Compact — only IDs and hash, app fetches full record
    const params = new URLSearchParams({
      h: receipt.contentHash?.slice(0, 16),  // first 16 chars of hash (app fetches full)
      s: SITE_ID,
      f: receipt.formLabel || "",
      t: Math.floor(Date.now() / 1000).toString(36), // compact timestamp
    });
    return `integra://attest/${receipt.integraId}?${params}`;
  }

  function buildWebFallbackUrl(qrData) {
    // For users without the app — opens web verification
    if (qrData.startsWith("integra://site/")) {
      return `https://verify.integraledger.com/site/${SITE_ID}`;
    }
    const match = qrData.match(/integra:\/\/attest\/([^?]+)/);
    if (match) return `https://verify.integraledger.com/a/${match[1]}`;
    return "https://verify.integraledger.com";
  }

  // ═══════════════════════════════════════════════════════════════
  // QR Badge Widget
  // ═══════════════════════════════════════════════════════════════
  let badgeEl = null;
  let currentQrData = null;
  let isExpanded = false;

  function renderBadge() {
    const posMap = {
      "bottom-right": "bottom:20px;right:20px;",
      "bottom-left": "bottom:20px;left:20px;",
      "top-right": "top:20px;right:20px;",
      "top-left": "top:20px;left:20px;",
    };
    const isDark = THEME === "dark";
    currentQrData = buildSiteQrData();

    badgeEl = document.createElement("div");
    badgeEl.id = "integra-badge";
    badgeEl.style.cssText = `
      position:fixed;${posMap[POSITION] || posMap["bottom-right"]}
      z-index:99999;
      font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
      transition:all 0.3s ease;
    `;

    // Collapsed state: small pill with mini QR
    badgeEl.innerHTML = buildCollapsedHtml(isDark);
    document.body.appendChild(badgeEl);

    // Click to expand/collapse
    badgeEl.addEventListener("click", (e) => {
      if (e.target.closest("a")) return; // let links work
      isExpanded = !isExpanded;
      if (isExpanded) {
        badgeEl.innerHTML = buildExpandedHtml(isDark, currentQrData);
        logEvent("badge_expand");
      } else {
        badgeEl.innerHTML = buildCollapsedHtml(isDark);
      }
    });

    logEvent("page_view", { title: document.title });
  }

  function buildCollapsedHtml(isDark) {
    const qrUrl = QR.generateQrImage(currentQrData, 32, 0);
    return `
      <div style="
        display:flex;align-items:center;gap:8px;
        padding:6px 12px 6px 6px;
        background:${isDark ? "#1a1a2e" : "#fff"};
        border:1px solid ${isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.08)"};
        border-radius:10px;
        box-shadow:0 2px 12px rgba(0,0,0,0.08);
        cursor:pointer;
        transition:box-shadow 0.2s,transform 0.2s;
      " onmouseenter="this.style.boxShadow='0 4px 20px rgba(37,99,235,0.15)';this.style.transform='translateY(-1px)'"
        onmouseleave="this.style.boxShadow='0 2px 12px rgba(0,0,0,0.08)';this.style.transform='translateY(0)'">
        <img src="${qrUrl}" width="32" height="32" style="border-radius:4px;image-rendering:pixelated;" alt="QR" />
        <div style="display:flex;flex-direction:column;line-height:1.2;">
          <span style="font-size:9px;text-transform:uppercase;letter-spacing:0.5px;color:${isDark ? "#888" : "#999"};">Verified by</span>
          <span style="font-size:13px;font-weight:700;color:#2563eb;">Integra</span>
        </div>
      </div>
    `;
  }

  function buildExpandedHtml(isDark, qrData) {
    const qrUrl = QR.generateQrImage(qrData, 180, 2);
    const webUrl = buildWebFallbackUrl(qrData);
    const isAttestation = qrData.includes("integra://attest/");
    const bg = isDark ? "#1a1a2e" : "#fff";
    const border = isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.08)";
    const text = isDark ? "#e0e0e0" : "#1a3a4a";
    const sub = isDark ? "#888" : "#999";

    return `
      <div style="
        width:240px;
        background:${bg};
        border:1px solid ${border};
        border-radius:16px;
        box-shadow:0 8px 32px rgba(0,0,0,0.12);
        overflow:hidden;
        cursor:default;
        animation:integra-fadein 0.3s ease;
      ">
        <!-- Header -->
        <div style="
          padding:14px 16px 10px;
          display:flex;align-items:center;justify-content:space-between;
        ">
          <div style="display:flex;align-items:center;gap:8px;">
            <svg width="20" height="22" viewBox="0 0 18 20" fill="none">
              <path d="M9 0L0 3.5V9.5C0 14.75 3.84 19.64 9 20C14.16 19.64 18 14.75 18 9.5V3.5L9 0Z" fill="#2563eb" fill-opacity="0.15"/>
              <path d="M9 1L1 4.1V9.5C1 14.2 4.41 18.67 9 19C13.59 18.67 17 14.2 17 9.5V4.1L9 1Z" stroke="#2563eb" stroke-width="1.2"/>
              <path d="M6 10L8 12L12 7.5" stroke="#2563eb" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span style="font-size:14px;font-weight:700;color:#2563eb;">Integra</span>
          </div>
          <span style="font-size:10px;color:${sub};cursor:pointer;" onclick="event.stopPropagation()">✕ close</span>
        </div>

        <!-- QR Code -->
        <div style="
          display:flex;flex-direction:column;align-items:center;
          padding:4px 20px 16px;
        ">
          <img src="${qrUrl}" width="180" height="180"
               style="border-radius:8px;image-rendering:pixelated;border:1px solid ${border};"
               alt="Scan with Integra app" />
          <p style="font-size:11px;color:${sub};margin-top:10px;text-align:center;line-height:1.4;">
            ${isAttestation
              ? "📱 Scan to verify this attestation"
              : "📱 Scan to verify this site"
            }
          </p>
        </div>

        ${isAttestation ? `
        <!-- Attestation info bar -->
        <div style="
          margin:0 16px 12px;padding:8px 10px;
          background:linear-gradient(135deg,#f0f7ff,#e8f4f0);
          border-radius:8px;font-size:11px;color:#1a3a4a;
        ">
          <div style="display:flex;align-items:center;gap:4px;font-weight:600;color:#2563eb;">
            <span>✓</span> Form Attested
          </div>
          <div style="color:#666;margin-top:3px;">
            Blockchain-anchored attestation
          </div>
        </div>
        ` : ""}

        <!-- Footer -->
        <div style="
          padding:10px 16px;
          border-top:1px solid ${border};
          display:flex;justify-content:space-between;align-items:center;
        ">
          <a href="${webUrl}" target="_blank" rel="noopener"
             style="font-size:10px;color:#2563eb;text-decoration:none;"
             onclick="event.stopPropagation()">
            Web verification →
          </a>
          <span style="font-size:9px;color:${sub};">
            ${isAttestation ? "attested" : "registered"}
          </span>
        </div>
      </div>
    `;
  }

  // Update QR to show attestation after form submit
  function updateBadgeToAttestation(receipt) {
    currentQrData = buildAttestQrData(receipt);
    const isDark = THEME === "dark";

    if (isExpanded) {
      badgeEl.innerHTML = buildExpandedHtml(isDark, currentQrData);
    } else {
      badgeEl.innerHTML = buildCollapsedHtml(isDark);
    }

    // Brief pulse animation to draw attention
    badgeEl.style.animation = "none";
    badgeEl.offsetHeight; // reflow
    badgeEl.style.animation = "integra-pulse 0.6s ease";
  }

  // ═══════════════════════════════════════════════════════════════
  // Form Attestation
  // ═══════════════════════════════════════════════════════════════
  async function attestForm(form, formData) {
    const contentHash = await sha256(canonicalize(formData));
    const payload = {
      siteId: SITE_ID,
      origin: window.location.origin,
      url: window.location.href,
      formId: form.id || form.getAttribute("name") || null,
      formLabel: form.dataset.integraLabel || form.id || "Unnamed Form",
      contentHash,
      fieldCount: Object.keys(formData).length,
      fieldNames: Object.keys(formData),
      timestamp: new Date().toISOString(),
    };
    if (form.dataset.integraIncludeValues === "true") payload.formData = formData;
    return apiCall("/attest/form", payload);
  }

  function injectHidden(form, name, value) {
    let el = form.querySelector(`input[name="${name}"]`);
    if (!el) {
      el = document.createElement("input");
      el.type = "hidden";
      el.name = name;
      form.appendChild(el);
    }
    el.value = value;
  }

  async function fetchSubmit(form, integraId, contentHash) {
    const fd = new FormData(form);
    return fetch(form.action || window.location.href, {
      method: (form.method || "POST").toUpperCase(),
      headers: { "X-Integra-Id": integraId, "X-Integra-Hash": contentHash },
      body: fd,
      redirect: "follow",
    });
  }

  // ═══════════════════════════════════════════════════════════════
  // Receipt (shown below form after attestation)
  // ═══════════════════════════════════════════════════════════════
  function showReceipt(form, receipt) {
    form.parentElement.querySelector(".integra-receipt")?.remove();
    const qrData = buildAttestQrData(receipt);
    const qrUrl = QR.generateQrImage(qrData, 80, 1);
    const webUrl = buildWebFallbackUrl(qrData);

    const el = document.createElement("div");
    el.className = "integra-receipt";
    el.style.cssText = `
      margin-top:16px;padding:16px 20px;
      background:linear-gradient(135deg,#f0f7ff,#e8f4f0);
      border:1px solid #b8d4e8;border-radius:12px;
      font-family:-apple-system,sans-serif;font-size:13px;color:#1a3a4a;line-height:1.5;
      animation:integra-fadein 0.4s ease;
    `;
    el.innerHTML = `
      <div style="display:flex;gap:16px;align-items:flex-start;">
        <!-- Mini QR -->
        <div style="flex-shrink:0;">
          <img src="${qrUrl}" width="80" height="80"
               style="border-radius:6px;image-rendering:pixelated;border:1px solid #d0e0ec;" />
          <div style="font-size:9px;color:#888;text-align:center;margin-top:4px;">Scan to verify</div>
        </div>
        <!-- Details -->
        <div style="flex:1;min-width:0;">
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
            <svg width="16" height="18" viewBox="0 0 18 20" fill="none">
              <path d="M9 0L0 3.5V9.5C0 14.75 3.84 19.64 9 20C14.16 19.64 18 14.75 18 9.5V3.5L9 0Z" fill="#2563eb" fill-opacity="0.15"/>
              <path d="M9 1L1 4.1V9.5C1 14.2 4.41 18.67 9 19C13.59 18.67 17 14.2 17 9.5V4.1L9 1Z" stroke="#2563eb" stroke-width="1.2"/>
              <path d="M6 10L8 12L12 7.5" stroke="#2563eb" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <strong style="color:#2563eb;font-size:13px;">Attested</strong>
          </div>
          <div style="font-size:11px;display:grid;grid-template-columns:auto 1fr;gap:2px 10px;">
            <span style="color:#888;">ID</span>
            <code style="font-size:10px;overflow:hidden;text-overflow:ellipsis;">${receipt.integraId}</code>
            <span style="color:#888;">Hash</span>
            <code style="font-size:10px;">${receipt.contentHash?.slice(0, 16)}...</code>
            <span style="color:#888;">SSL</span>
            <code style="font-size:10px;">${receipt.sslCert?.issuer || "Verified"}</code>
          </div>
          <a href="${webUrl}" target="_blank" rel="noopener"
             style="display:inline-block;margin-top:8px;font-size:10px;color:#2563eb;text-decoration:none;">
            View full record →
          </a>
        </div>
      </div>
    `;
    form.parentElement.insertBefore(el, form.nextSibling);
  }

  // ═══════════════════════════════════════════════════════════════
  // Hook Forms
  // ═══════════════════════════════════════════════════════════════
  function hookForms() {
    document
      .querySelectorAll('form[data-integra-attest="true"], [data-integra-attest="true"] form')
      .forEach((form) => {
        if (form._integraHooked) return;
        form._integraHooked = true;

        const mode = form.dataset.integraMode || "native";

        // Label above submit
        const btn = form.querySelector('button[type="submit"], input[type="submit"]');
        if (btn) {
          const lbl = document.createElement("div");
          lbl.style.cssText = "display:flex;align-items:center;gap:6px;margin-bottom:10px;font-size:11px;font-family:-apple-system,sans-serif;color:#666;";
          lbl.innerHTML = `
            <svg width="14" height="16" viewBox="0 0 18 20" fill="none">
              <path d="M9 0L0 3.5V9.5C0 14.75 3.84 19.64 9 20C14.16 19.64 18 14.75 18 9.5V3.5L9 0Z" fill="#2563eb" fill-opacity="0.15"/>
              <path d="M9 1L1 4.1V9.5C1 14.2 4.41 18.67 9 19C13.59 18.67 17 14.2 17 9.5V4.1L9 1Z" stroke="#2563eb" stroke-width="1"/>
              <path d="M6 10L8 12L12 7.5" stroke="#2563eb" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <span>This form is attested by <strong style="color:#2563eb;">Integra Ledger</strong></span>
          `;
          btn.parentElement.insertBefore(lbl, btn);
        }

        // Submit intercept
        form.addEventListener("submit", async function handler(e) {
          e.preventDefault();

          const formData = serializeForm(form);
          const origLabel = btn?.textContent || btn?.value;
          if (btn) { btn.disabled = true; btn.textContent ? (btn.textContent = "Attesting...") : (btn.value = "Attesting..."); }

          try {
            logEvent("form_submit", { formId: form.id });

            const receipt = await attestForm(form, formData);
            logEvent("attestation_created", { integraId: receipt.integraId });

            // Inject hidden fields
            injectHidden(form, "integraId", receipt.integraId);
            injectHidden(form, "integraHash", receipt.contentHash);

            // Update the floating QR badge
            updateBadgeToAttestation(receipt);

            if (mode === "fetch") {
              const res = await fetchSubmit(form, receipt.integraId, receipt.contentHash);
              showReceipt(form, receipt);
              form.dispatchEvent(new CustomEvent("integra:attested", {
                detail: { formData, receipt, response: res }, bubbles: true,
              }));
            } else {
              showReceipt(form, receipt);
              form.dispatchEvent(new CustomEvent("integra:attested", {
                detail: { formData, receipt }, bubbles: true,
              }));
              form.removeEventListener("submit", handler);
              setTimeout(() => form.submit(), 800);
              return;
            }
          } catch (err) {
            console.error("[Integra]", err);
            form.dispatchEvent(new CustomEvent("integra:error", {
              detail: { formData, error: err }, bubbles: true,
            }));
            form.removeEventListener("submit", handler);
            form.submit();
            return;
          } finally {
            if (btn) { btn.disabled = false; btn.textContent ? (btn.textContent = origLabel) : (btn.value = origLabel); }
          }
        });
      });
  }

  // ═══════════════════════════════════════════════════════════════
  // Public API
  // ═══════════════════════════════════════════════════════════════
  window.Integra = {
    attest: async (data, label) => {
      const contentHash = await sha256(canonicalize(data));
      const receipt = await apiCall("/attest/form", {
        siteId: SITE_ID, origin: window.location.origin, contentHash,
        formLabel: label || "Manual", formData: data, timestamp: new Date().toISOString(),
      });
      updateBadgeToAttestation(receipt);
      return receipt;
    },
    verify: (integraId) => apiCall("/verify", { integraId }),
    getQrData: () => currentQrData,
    siteId: SITE_ID,
  };

  // ═══════════════════════════════════════════════════════════════
  // Init
  // ═══════════════════════════════════════════════════════════════
  function init() {
    if (!document.getElementById("integra-styles")) {
      const s = document.createElement("style");
      s.id = "integra-styles";
      s.textContent = `
        @keyframes integra-fadein { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
        @keyframes integra-pulse { 0% { transform:scale(1); } 50% { transform:scale(1.05); } 100% { transform:scale(1); } }
      `;
      document.head.appendChild(s);
    }
    renderBadge();
    hookForms();
    new MutationObserver(() => hookForms()).observe(document.body, { childList: true, subtree: true });
  }

  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", init) : init();
})();
