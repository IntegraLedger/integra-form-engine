/**
 * Integra Auth & Signing Module
 *
 * Three auth modes:
 *   1. API Key  → HMAC-SHA256 signature (simplest)
 *   2. Keypair  → ECDSA P-256 signature (generated in browser, exportable)
 *   3. Wallet   → Ethereum wallet signature via window.ethereum (MetaMask etc)
 *
 * On form submit:
 *   - Sign the attestation payload (roundTripHash + integraId + timestamp)
 *   - Inject as hidden fields: integraSignature, integraSignedBy, integraSigAlg
 *   - Also set custom headers if fetch/XHR (X-Integra-Signature, X-Integra-Signed-By)
 *
 * Keys stored in chrome.storage.local (never synced).
 * Private keys encrypted with user passphrase via AES-GCM.
 */

const IntegraAuth = (function () {
  "use strict";

  // ═══════════════════════════════════════════════════════════
  // State
  // ═══════════════════════════════════════════════════════════
  let _session = null;  // { method, userId, displayName, publicKey, signingKey }

  // ═══════════════════════════════════════════════════════════
  // Crypto helpers
  // ═══════════════════════════════════════════════════════════
  function toHex(buf) {
    return Array.from(new Uint8Array(buf), b => b.toString(16).padStart(2, "0")).join("");
  }
  function fromHex(hex) {
    const bytes = new Uint8Array(hex.length / 2);
    for (let i = 0; i < hex.length; i += 2) bytes[i / 2] = parseInt(hex.substr(i, 2), 16);
    return bytes;
  }
  function toBase64(buf) {
    return btoa(String.fromCharCode(...new Uint8Array(buf)));
  }
  function fromBase64(b64) {
    const bin = atob(b64);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
    return buf;
  }

  // AES-GCM encrypt (for storing private keys)
  async function encrypt(data, passphrase) {
    const enc = new TextEncoder();
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(passphrase), "PBKDF2", false, ["deriveKey"]);
    const key = await crypto.subtle.deriveKey(
      { name: "PBKDF2", salt, iterations: 100000, hash: "SHA-256" },
      keyMaterial, { name: "AES-GCM", length: 256 }, false, ["encrypt"]
    );
    const ct = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, enc.encode(data));
    return { salt: toBase64(salt), iv: toBase64(iv), ct: toBase64(ct) };
  }

  async function decrypt(encrypted, passphrase) {
    const enc = new TextEncoder();
    const keyMaterial = await crypto.subtle.importKey("raw", enc.encode(passphrase), "PBKDF2", false, ["deriveKey"]);
    const key = await crypto.subtle.deriveKey(
      { name: "PBKDF2", salt: fromBase64(encrypted.salt), iterations: 100000, hash: "SHA-256" },
      keyMaterial, { name: "AES-GCM", length: 256 }, false, ["decrypt"]
    );
    const pt = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: fromBase64(encrypted.iv) }, key, fromBase64(encrypted.ct)
    );
    return new TextDecoder().decode(pt);
  }

  // ═══════════════════════════════════════════════════════════
  // 1. API Key Auth (HMAC-SHA256)
  // ═══════════════════════════════════════════════════════════
  async function signInWithApiKey(apiKey, userId, displayName) {
    // Derive signing key from API key
    const keyData = new TextEncoder().encode(apiKey);
    const signingKey = await crypto.subtle.importKey(
      "raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
    );
    // Public identifier = SHA-256(apiKey) truncated
    const pkHash = await crypto.subtle.digest("SHA-256", keyData);
    const publicKey = "hmac_" + toHex(pkHash).slice(0, 16);

    _session = {
      method: "api-key",
      userId: userId || publicKey,
      displayName: displayName || "API Key User",
      publicKey,
      signingKey,
      algorithm: "HMAC-SHA256",
    };

    await saveSession();
    return _session;
  }

  async function signWithApiKey(payload) {
    const data = new TextEncoder().encode(payload);
    const sig = await crypto.subtle.sign("HMAC", _session.signingKey, data);
    return toHex(sig);
  }

  // ═══════════════════════════════════════════════════════════
  // 2. Keypair Auth (ECDSA P-256)
  // ═══════════════════════════════════════════════════════════
  async function signInWithKeypair(passphrase) {
    // Check for existing keypair
    const stored = await getStored("integraKeypair");

    let keyPair, publicKeyHex;

    if (stored) {
      // Decrypt existing private key
      try {
        const privateKeyJwk = JSON.parse(await decrypt(stored.encryptedPrivateKey, passphrase));
        const privateKey = await crypto.subtle.importKey(
          "jwk", privateKeyJwk,
          { name: "ECDSA", namedCurve: "P-256" }, true, ["sign"]
        );
        const publicKey = await crypto.subtle.importKey(
          "jwk", stored.publicKeyJwk,
          { name: "ECDSA", namedCurve: "P-256" }, true, ["verify"]
        );
        keyPair = { privateKey, publicKey };
        publicKeyHex = stored.publicKeyHex;
      } catch (e) {
        throw new Error("Wrong passphrase or corrupted key");
      }
    } else {
      // Generate new keypair
      keyPair = await crypto.subtle.generateKey(
        { name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]
      );

      // Export for storage
      const privateKeyJwk = await crypto.subtle.exportKey("jwk", keyPair.privateKey);
      const publicKeyJwk = await crypto.subtle.exportKey("jwk", keyPair.publicKey);
      const publicKeyRaw = await crypto.subtle.exportKey("raw", keyPair.publicKey);
      publicKeyHex = toHex(publicKeyRaw);

      // Encrypt private key with passphrase
      const encryptedPrivateKey = await encrypt(JSON.stringify(privateKeyJwk), passphrase);

      await setStored("integraKeypair", {
        encryptedPrivateKey,
        publicKeyJwk,
        publicKeyHex,
        created: new Date().toISOString(),
      });
    }

    _session = {
      method: "keypair",
      userId: "ecdsa_" + publicKeyHex.slice(0, 16),
      displayName: "ECDSA Key " + publicKeyHex.slice(0, 8) + "…",
      publicKey: publicKeyHex,
      signingKey: keyPair.privateKey,
      verifyKey: keyPair.publicKey,
      algorithm: "ECDSA-P256-SHA256",
    };

    await saveSession();
    return _session;
  }

  async function signWithKeypair(payload) {
    const data = new TextEncoder().encode(payload);
    const sig = await crypto.subtle.sign(
      { name: "ECDSA", hash: "SHA-256" }, _session.signingKey, data
    );
    return toHex(sig);
  }

  // ═══════════════════════════════════════════════════════════
  // 3. Wallet Auth (Ethereum / MetaMask)
  // ═══════════════════════════════════════════════════════════
  async function signInWithWallet() {
    if (!window.ethereum) throw new Error("No Ethereum wallet detected");

    const accounts = await window.ethereum.request({ method: "eth_requestAccounts" });
    if (!accounts || accounts.length === 0) throw new Error("No account selected");

    const address = accounts[0];

    _session = {
      method: "wallet",
      userId: address,
      displayName: address.slice(0, 6) + "…" + address.slice(-4),
      publicKey: address,
      signingKey: null, // wallet handles signing
      algorithm: "ETH-personal_sign",
    };

    await saveSession();
    return _session;
  }

  async function signWithWallet(payload) {
    const msg = "0x" + toHex(new TextEncoder().encode(payload));
    const sig = await window.ethereum.request({
      method: "personal_sign",
      params: [msg, _session.userId],
    });
    return sig; // 0x-prefixed hex
  }

  // ═══════════════════════════════════════════════════════════
  // Unified sign function
  // ═══════════════════════════════════════════════════════════
  async function signPayload(payload) {
    if (!_session) throw new Error("Not signed in");

    let signature;
    switch (_session.method) {
      case "api-key": signature = await signWithApiKey(payload); break;
      case "keypair": signature = await signWithKeypair(payload); break;
      case "wallet":  signature = await signWithWallet(payload); break;
      default: throw new Error("Unknown auth method: " + _session.method);
    }

    return {
      signature,
      signedBy: _session.publicKey,
      userId: _session.userId,
      displayName: _session.displayName,
      algorithm: _session.algorithm,
      method: _session.method,
      timestamp: new Date().toISOString(),
    };
  }

  // ═══════════════════════════════════════════════════════════
  // Build signable payload from attestation
  // ═══════════════════════════════════════════════════════════
  function buildSignablePayload(attestation) {
    // Canonical string that gets signed
    // Includes the key binding fields so the signature covers:
    //   - what was sent (requestHash)
    //   - what came back (responseHash)
    //   - the binding (roundTripHash)
    //   - the integra ID
    //   - timestamp
    const parts = [
      "integra-attest-v1",
      attestation.integraId,
      attestation.roundTripHash,
      attestation.requestHash,
      attestation.responseHash || "none",
      attestation.merkleRoot,
      attestation.timestamp,
    ];
    return parts.join("|");
  }

  // ═══════════════════════════════════════════════════════════
  // Inject signature into form
  // ═══════════════════════════════════════════════════════════
  function injectSignatureFields(form, sigResult) {
    const inject = (name, value) => {
      // Remove existing
      const existing = form.querySelector(`input[name="${name}"]`);
      if (existing) existing.remove();
      // Add new hidden field
      const input = document.createElement("input");
      input.type = "hidden";
      input.name = name;
      input.value = value;
      input.setAttribute("data-integra-injected", "true");
      form.appendChild(input);
    };

    inject("integraSignature", sigResult.signature);
    inject("integraSignedBy", sigResult.signedBy);
    inject("integraSigAlg", sigResult.algorithm);
    inject("integraSigMethod", sigResult.method);
    inject("integraSigTimestamp", sigResult.timestamp);
    inject("integraSigUserId", sigResult.userId);
  }

  // Build headers for fetch/XHR injection
  function buildSignatureHeaders(sigResult) {
    return {
      "X-Integra-Signature": sigResult.signature,
      "X-Integra-Signed-By": sigResult.signedBy,
      "X-Integra-Sig-Algorithm": sigResult.algorithm,
      "X-Integra-Sig-Method": sigResult.method,
      "X-Integra-Sig-Timestamp": sigResult.timestamp,
      "X-Integra-Sig-User-Id": sigResult.userId,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // Session persistence (chrome.storage.local or localStorage)
  // ═══════════════════════════════════════════════════════════
  const isExtension = typeof chrome !== "undefined" && chrome.storage;

  async function getStored(key) {
    if (isExtension) {
      return new Promise(r => chrome.storage.local.get(key, d => r(d[key] || null)));
    }
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : null;
  }

  async function setStored(key, value) {
    if (isExtension) {
      return new Promise(r => chrome.storage.local.set({ [key]: value }, r));
    }
    localStorage.setItem(key, JSON.stringify(value));
  }

  async function removeStored(key) {
    if (isExtension) {
      return new Promise(r => chrome.storage.local.remove(key, r));
    }
    localStorage.removeItem(key);
  }

  async function saveSession() {
    if (!_session) return;
    // Save non-sensitive session info (no private keys)
    await setStored("integraSession", {
      method: _session.method,
      userId: _session.userId,
      displayName: _session.displayName,
      publicKey: _session.publicKey,
      algorithm: _session.algorithm,
    });
  }

  // ═══════════════════════════════════════════════════════════
  // Restore session (needs re-auth for signing, but shows status)
  // ═══════════════════════════════════════════════════════════
  async function restoreSession() {
    const saved = await getStored("integraSession");
    if (!saved) return null;

    // Session exists but signing key is gone (page reload / extension restart)
    // User needs to re-authenticate to sign, but we can show their identity
    _session = {
      ...saved,
      signingKey: null, // needs re-auth
      _needsReauth: true,
    };
    return _session;
  }

  function isSignedIn() {
    return _session !== null && !_session._needsReauth;
  }

  function needsReauth() {
    return _session !== null && _session._needsReauth;
  }

  function getSession() {
    return _session ? { ...{}, ..._session, signingKey: undefined, verifyKey: undefined } : null;
  }

  async function signOut() {
    _session = null;
    await removeStored("integraSession");
    // Note: keypair stays in storage for future use
  }

  async function clearAll() {
    _session = null;
    await removeStored("integraSession");
    await removeStored("integraKeypair");
  }

  // ═══════════════════════════════════════════════════════════
  // Export public key for verification
  // ═══════════════════════════════════════════════════════════
  async function exportPublicKey() {
    if (!_session) return null;
    if (_session.method === "keypair" && _session.verifyKey) {
      const raw = await crypto.subtle.exportKey("raw", _session.verifyKey);
      return { format: "raw-hex", key: toHex(raw), algorithm: "ECDSA-P256" };
    }
    return { format: "identifier", key: _session.publicKey, algorithm: _session.algorithm };
  }

  // ═══════════════════════════════════════════════════════════
  // Public API
  // ═══════════════════════════════════════════════════════════
  return {
    // Auth
    signInWithApiKey,
    signInWithKeypair,
    signInWithWallet,
    signOut,
    clearAll,
    restoreSession,

    // Status
    isSignedIn,
    needsReauth,
    getSession,
    exportPublicKey,

    // Signing
    signPayload,
    buildSignablePayload,

    // Injection
    injectSignatureFields,
    buildSignatureHeaders,
  };

})();

// Export for extension / module
if (typeof module !== "undefined") module.exports = IntegraAuth;
if (typeof window !== "undefined") window.IntegraAuth = IntegraAuth;
