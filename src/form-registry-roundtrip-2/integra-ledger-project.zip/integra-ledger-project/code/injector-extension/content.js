/**
 * Integra Attest — Content Script
 *
 * Modes:
 *   AUTO   — hooks every <form> on the page, attests on submit
 *   MANUAL — Ctrl+Shift+A opens overlay to pick forms, Ctrl+Shift+S attests focused form
 *   OFF    — extension disabled for this domain
 *
 * What it does on submit:
 *   1. Intercepts form submit
 *   2. Hashes each field individually (HMAC-SHA256 with random salt)
 *   3. Computes Merkle root + content hash
 *   4. Calls /v1/attest/form → gets integraId
 *   5. Injects hidden fields (integraId, integraHash, integraMerkle)
 *   6. Shows receipt badge on the form
 *   7. Lets form submit normally
 */

(function () {
  "use strict";

  // ═══════════════════════════════════════════════════════════
  // State
  // ═══════════════════════════════════════════════════════════
  const INTEGRA_API = "https://api.integraledger.com";
  let config = {
    mode: "manual",       // auto | manual | off
    apiKey: "",
    siteId: "",
    showBadge: true,
    showReceipt: true,
    domainRules: {},      // { "example.com": "auto", "bank.com": "off" }
    excludeSelectors: [   // never hook these
      "[data-integra-skip]",
      ".integra-skip",
      'form[action*="search"]',
      'form[role="search"]',
    ],
  };

  let hookedForms = new WeakSet();
  let overlayVisible = false;
  let formBadges = new Map(); // form element → badge element
  let _pendingSignatureHeaders = null; // headers to inject on next fetch/XHR

  // ═══════════════════════════════════════════════════════════
  // Fetch/XHR Interceptor — injects signature headers
  // ═══════════════════════════════════════════════════════════
  const _origFetch = window.fetch;
  window.fetch = function(input, init) {
    if (_pendingSignatureHeaders) {
      init = init || {};
      const headers = new Headers(init.headers || {});
      for (const [k, v] of Object.entries(_pendingSignatureHeaders)) {
        headers.set(k, v);
      }
      init.headers = headers;
      console.log("[Integra] Injected signature headers into fetch:", Object.keys(_pendingSignatureHeaders));
      _pendingSignatureHeaders = null;
    }
    return _origFetch.call(this, input, init);
  };

  const _origXHROpen = XMLHttpRequest.prototype.open;
  const _origXHRSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    this._integraUrl = url;
    this._integraMethod = method;
    return _origXHROpen.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function(body) {
    if (_pendingSignatureHeaders && this._integraMethod &&
        ["POST","PUT","PATCH"].includes(this._integraMethod.toUpperCase())) {
      for (const [k, v] of Object.entries(_pendingSignatureHeaders)) {
        try { this.setRequestHeader(k, v); } catch(e) {}
      }
      console.log("[Integra] Injected signature headers into XHR:", Object.keys(_pendingSignatureHeaders));
      _pendingSignatureHeaders = null;
    }
    return _origXHRSend.call(this, body);
  };

  // ═══════════════════════════════════════════════════════════
  // Load config from storage
  // ═══════════════════════════════════════════════════════════
  async function loadConfig() {
    try {
      const stored = await chrome.storage.sync.get("integraConfig");
      if (stored.integraConfig) {
        Object.assign(config, stored.integraConfig);
      }
      // Check domain-specific rule
      const domain = location.hostname;
      if (config.domainRules[domain]) {
        config.mode = config.domainRules[domain];
      }
    } catch (e) {
      // Extension context may not be available
    }
  }

  // ═══════════════════════════════════════════════════════════
  // Crypto
  // ═══════════════════════════════════════════════════════════
  function generateSalt() {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
  }

  async function sha256(str) {
    const buf = new TextEncoder().encode(str);
    const hash = await crypto.subtle.digest("SHA-256", buf);
    return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, "0")).join("");
  }

  async function hmacSha256(key, message) {
    const keyData = new TextEncoder().encode(key);
    const msgData = new TextEncoder().encode(message);
    const cryptoKey = await crypto.subtle.importKey(
      "raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
    );
    const sig = await crypto.subtle.sign("HMAC", cryptoKey, msgData);
    return Array.from(new Uint8Array(sig), b => b.toString(16).padStart(2, "0")).join("");
  }

  async function hashField(fieldName, fieldValue, salt) {
    return hmacSha256(salt, `${fieldName}:${fieldValue}`);
  }

  async function hashAllFields(fields, salt) {
    const fieldHashes = {};
    const sortedKeys = Object.keys(fields).sort();

    for (const name of sortedKeys) {
      fieldHashes[name] = await hashField(name, String(fields[name]), salt);
    }

    // Merkle root
    let leaves = Object.values(fieldHashes).map(h => h);
    while (leaves.length > 1) {
      const next = [];
      for (let i = 0; i < leaves.length; i += 2) {
        const left = leaves[i];
        const right = i + 1 < leaves.length ? leaves[i + 1] : leaves[i];
        next.push(await sha256(left + right));
      }
      leaves = next;
    }

    const contentHash = await sha256(JSON.stringify(fields, Object.keys(fields).sort()));

    return {
      salt,
      fieldHashes,
      merkleRoot: leaves[0] || await sha256("empty"),
      contentHash,
      fieldCount: sortedKeys.length,
    };
  }

  // ═══════════════════════════════════════════════════════════
  // Form Discovery
  // ═══════════════════════════════════════════════════════════
  function discoverForms() {
    const forms = document.querySelectorAll("form");
    const results = [];

    forms.forEach((form, idx) => {
      // Skip excluded
      const shouldSkip = config.excludeSelectors.some(sel => {
        try { return form.matches(sel); } catch { return false; }
      });
      if (shouldSkip) return;

      // Skip forms with no real inputs
      const inputs = form.querySelectorAll(
        "input:not([type=hidden]):not([type=submit]):not([type=button]), textarea, select"
      );
      if (inputs.length === 0) return;

      // Identify the form
      const label = form.getAttribute("aria-label")
        || form.getAttribute("name")
        || form.getAttribute("id")
        || form.querySelector("h1,h2,h3,h4,legend")?.textContent?.trim()
        || `Form ${idx + 1}`;

      const action = form.action || "N/A";
      const method = (form.method || "GET").toUpperCase();

      results.push({
        element: form,
        label: label.slice(0, 60),
        action,
        method,
        fieldCount: inputs.length,
        hooked: hookedForms.has(form),
      });
    });

    return results;
  }

  // ═══════════════════════════════════════════════════════════
  // Form Hooking — intercept submit
  // ═══════════════════════════════════════════════════════════
  function hookForm(form) {
    if (hookedForms.has(form)) return;
    hookedForms.add(form);

    // Add visual indicator
    addFormBadge(form, "pending");

    form.addEventListener("submit", async function handler(e) {
      e.preventDefault();
      e.stopImmediatePropagation();

      updateFormBadge(form, "attesting");

      try {
        // Collect form data
        const formData = {};
        const fd = new FormData(form);
        for (const [k, v] of fd.entries()) {
          if (typeof v === "string") formData[k] = v;
        }

        // Salt + hash
        const salt = generateSalt();
        const result = await hashAllFields(formData, salt);

        // Call API
        const receipt = await callAttestApi({
          origin: location.origin,
          path: location.pathname,
          formLabel: form.getAttribute("data-integra-label") || form.getAttribute("name") || "Form",
          contentHash: result.contentHash,
          merkleRoot: result.merkleRoot,
          fieldHashes: result.fieldHashes,
          fieldCount: result.fieldCount,
          salt: result.salt,
          ssl: location.protocol === "https:",
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString(),
        });

        // Inject attestation hidden fields
        injectHiddenField(form, "integraId", receipt.integraId);
        injectHiddenField(form, "integraHash", result.contentHash);
        injectHiddenField(form, "integraMerkle", result.merkleRoot);
        injectHiddenField(form, "integraSalt", result.salt);
        injectHiddenField(form, "integraTimestamp", receipt.timestamp);

        // ── Sign payload if authenticated ──
        let sigResult = null;
        if (typeof IntegraAuth !== "undefined" && IntegraAuth.isSignedIn()) {
          try {
            const signable = IntegraAuth.buildSignablePayload({
              integraId: receipt.integraId,
              roundTripHash: receipt.roundTripHash || result.contentHash,
              requestHash: result.contentHash,
              responseHash: receipt.responseHash || "none",
              merkleRoot: result.merkleRoot,
              timestamp: receipt.timestamp,
            });
            sigResult = await IntegraAuth.signPayload(signable);

            // Inject signature as hidden fields
            IntegraAuth.injectSignatureFields(form, sigResult);

            // Store headers for fetch interception
            _pendingSignatureHeaders = IntegraAuth.buildSignatureHeaders(sigResult);

            console.log("[Integra] ✅ Payload signed by", sigResult.displayName, sigResult.algorithm);
          } catch (sigErr) {
            console.warn("[Integra] Signing failed (submitting unsigned):", sigErr);
          }
        }

        // Update badge
        updateFormBadge(form, "attested", receipt, null, sigResult);

        // Show receipt if enabled
        if (config.showReceipt) {
          showReceipt(form, receipt, result, sigResult);
        }

        // Re-submit the form natively
        // Small delay so user sees the badge
        setTimeout(() => {
          form.removeEventListener("submit", handler);
          // Use requestSubmit if available (fires submit event), else submit()
          if (form.requestSubmit) {
            form.requestSubmit();
          } else {
            form.submit();
          }
        }, 800);

      } catch (err) {
        console.error("[Integra] Attestation failed:", err);
        updateFormBadge(form, "error", null, err.message);
        // Let form submit anyway
        setTimeout(() => {
          form.removeEventListener("submit", handler);
          form.submit();
        }, 500);
      }
    }, { capture: true });
  }

  function unhookForm(form) {
    // We can't remove the listener (anonymous), but we can mark it
    hookedForms.delete(form);
    removeFormBadge(form);
  }

  function injectHiddenField(form, name, value) {
    let input = form.querySelector(`input[name="${name}"]`);
    if (!input) {
      input = document.createElement("input");
      input.type = "hidden";
      input.name = name;
      form.appendChild(input);
    }
    input.value = value;
  }

  // ═══════════════════════════════════════════════════════════
  // API Call (simulated for demo, real endpoint in production)
  // ═══════════════════════════════════════════════════════════
  async function callAttestApi(payload) {
    // Build auth headers if signed in
    let authHeaders = {};
    if (typeof IntegraAuth !== "undefined" && IntegraAuth.isSignedIn()) {
      const session = IntegraAuth.getSession();
      authHeaders["X-Integra-Signed-By"] = session.publicKey;
      authHeaders["X-Integra-Sig-Algorithm"] = session.algorithm;
    }

    // In production: POST to INTEGRA_API + "/v1/attest/form"
    try {
      const resp = await fetch(INTEGRA_API + "/v1/attest/form", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(config.apiKey ? { "Authorization": `Bearer ${config.apiKey}` } : {}),
          ...authHeaders,
        },
        body: JSON.stringify(payload),
      });
      if (resp.ok) return resp.json();
    } catch (e) {
      // API not reachable — generate local receipt
    }

    // Fallback: local attestation receipt
    const id = "ig_" + payload.contentHash.slice(0, 12);
    return {
      integraId: id,
      contentHash: payload.contentHash,
      merkleRoot: payload.merkleRoot,
      timestamp: payload.timestamp,
      verifyUrl: `https://verify.integraledger.com/a/${id}`,
      status: "local", // not server-verified
    };
  }

  // ═══════════════════════════════════════════════════════════
  // Form Badges — small pill on each hooked form
  // ═══════════════════════════════════════════════════════════
  function addFormBadge(form, state) {
    if (!config.showBadge) return;

    // Position relative to the form
    const existing = formBadges.get(form);
    if (existing) existing.remove();

    // Make form position relative if static
    const pos = getComputedStyle(form).position;
    if (pos === "static") form.style.position = "relative";

    const badge = document.createElement("div");
    badge.className = "integra-form-badge";
    badge.setAttribute("data-integra-state", state);
    badge.innerHTML = `
      <span class="integra-fb-icon">${stateIcon(state)}</span>
      <span class="integra-fb-text">${stateText(state)}</span>
    `;
    form.appendChild(badge);
    formBadges.set(form, badge);
  }

  function updateFormBadge(form, state, receipt, error, sigResult) {
    const badge = formBadges.get(form);
    if (!badge) return addFormBadge(form, state);

    badge.setAttribute("data-integra-state", state);
    badge.querySelector(".integra-fb-icon").textContent = stateIcon(state);

    let text = stateText(state);
    if (receipt?.integraId) text += ` · ${receipt.integraId}`;
    if (sigResult) text += ` · 🔏 ${sigResult.displayName}`;
    if (error) text += ` · ${error}`;
    badge.querySelector(".integra-fb-text").textContent = text;
  }

  function removeFormBadge(form) {
    const badge = formBadges.get(form);
    if (badge) badge.remove();
    formBadges.delete(form);
  }

  function stateIcon(state) {
    return { pending: "🔒", attesting: "⏳", attested: "✅", error: "⚠️" }[state] || "🔒";
  }
  function stateText(state) {
    return { pending: "Integra Armed", attesting: "Attesting...", attested: "Attested", error: "Failed" }[state] || "";
  }

  // ═══════════════════════════════════════════════════════════
  // Receipt — shows under the form after attestation
  // ═══════════════════════════════════════════════════════════
  function showReceipt(form, receipt, hashResult, sigResult) {
    const existing = form.querySelector(".integra-receipt");
    if (existing) existing.remove();

    const sigRows = sigResult ? `
        <div class="integra-receipt-row" style="border-top:1px solid #222244;margin-top:4px;padding-top:4px">
          <span class="integra-receipt-label" style="color:#22c55e">🔏 Signed</span>
          <span class="integra-receipt-value" style="color:#34d399">${sigResult.displayName} · ${sigResult.algorithm}</span>
        </div>
        <div class="integra-receipt-row">
          <span class="integra-receipt-label">Sig</span>
          <span class="integra-receipt-value mono">${sigResult.signature.slice(0, 24)}...</span>
        </div>
        <div class="integra-receipt-row">
          <span class="integra-receipt-label">Key</span>
          <span class="integra-receipt-value mono">${sigResult.signedBy.slice(0, 24)}...</span>
        </div>
    ` : `
        <div class="integra-receipt-row" style="border-top:1px solid #222244;margin-top:4px;padding-top:4px">
          <span class="integra-receipt-label" style="color:#666">Signature</span>
          <span class="integra-receipt-value" style="color:#555">Unsigned (sign in to sign)</span>
        </div>
    `;

    const el = document.createElement("div");
    el.className = "integra-receipt";
    el.innerHTML = `
      <div class="integra-receipt-header">
        <span>✅ Attested by Integra Ledger</span>
        <button class="integra-receipt-close" title="Close">✕</button>
      </div>
      <div class="integra-receipt-body">
        <div class="integra-receipt-row">
          <span class="integra-receipt-label">ID</span>
          <span class="integra-receipt-value">${receipt.integraId}</span>
        </div>
        <div class="integra-receipt-row">
          <span class="integra-receipt-label">Hash</span>
          <span class="integra-receipt-value mono">${receipt.contentHash.slice(0, 24)}...</span>
        </div>
        <div class="integra-receipt-row">
          <span class="integra-receipt-label">Merkle</span>
          <span class="integra-receipt-value mono">${receipt.merkleRoot.slice(0, 24)}...</span>
        </div>
        <div class="integra-receipt-row">
          <span class="integra-receipt-label">Fields</span>
          <span class="integra-receipt-value">${hashResult.fieldCount} hashed</span>
        </div>
        ${receipt.status === "local" ? '<div class="integra-receipt-warn">⚠ Local attestation (API unreachable)</div>' : ""}
        ${sigRows}
        <a href="${receipt.verifyUrl}" target="_blank" class="integra-receipt-link">Verify →</a>
      </div>
    `;

    el.querySelector(".integra-receipt-close").onclick = () => el.remove();
    form.after(el);
  }

  // ═══════════════════════════════════════════════════════════
  // Overlay — Ctrl+Shift+A
  // ═══════════════════════════════════════════════════════════
  function toggleOverlay() {
    if (overlayVisible) return closeOverlay();
    overlayVisible = true;

    const forms = discoverForms();
    const overlay = document.createElement("div");
    overlay.id = "integra-overlay";
    overlay.innerHTML = `
      <div class="integra-overlay-panel">
        <div class="integra-overlay-header">
          <div class="integra-overlay-title">
            <span class="integra-overlay-logo">🔐</span>
            Integra Attest
          </div>
          <div class="integra-overlay-controls">
            <select id="integra-mode-select">
              <option value="auto" ${config.mode === "auto" ? "selected" : ""}>Auto (all forms)</option>
              <option value="manual" ${config.mode === "manual" ? "selected" : ""}>Manual (pick forms)</option>
              <option value="off" ${config.mode === "off" ? "selected" : ""}>Off (this domain)</option>
            </select>
            <button id="integra-overlay-close" title="Close (Esc)">✕</button>
          </div>
        </div>

        <div class="integra-overlay-body">
          ${forms.length === 0
            ? '<div class="integra-overlay-empty">No forms detected on this page.</div>'
            : `
              <div class="integra-overlay-subtitle">${forms.length} form${forms.length > 1 ? "s" : ""} detected</div>
              <div class="integra-overlay-forms">
                ${forms.map((f, i) => `
                  <div class="integra-overlay-form-row" data-form-idx="${i}">
                    <div class="integra-overlay-form-info">
                      <div class="integra-overlay-form-label">${escapeHtml(f.label)}</div>
                      <div class="integra-overlay-form-meta">${f.method} · ${f.fieldCount} fields · ${f.action.slice(0, 50)}</div>
                    </div>
                    <div class="integra-overlay-form-actions">
                      <label class="integra-toggle">
                        <input type="checkbox" ${f.hooked ? "checked" : ""} data-toggle-idx="${i}" />
                        <span class="integra-toggle-slider"></span>
                      </label>
                      <button class="integra-overlay-highlight-btn" data-highlight-idx="${i}" title="Highlight form">👁</button>
                    </div>
                  </div>
                `).join("")}
              </div>
            `}

          <div class="integra-overlay-footer">
            <div class="integra-overlay-shortcuts">
              <kbd>⌘⇧A</kbd> Toggle overlay · <kbd>⌘⇧S</kbd> Attest focused form · <kbd>Esc</kbd> Close
            </div>
            <div class="integra-overlay-domain">
              ${location.hostname} · Mode: <strong>${config.mode}</strong>
            </div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    // Event handlers
    overlay.querySelector("#integra-overlay-close").onclick = closeOverlay;
    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) closeOverlay();
    });

    // Mode select
    overlay.querySelector("#integra-mode-select").onchange = async (e) => {
      const newMode = e.target.value;
      config.mode = newMode;
      config.domainRules[location.hostname] = newMode;
      await saveConfig();

      if (newMode === "auto") hookAllForms();
      else if (newMode === "off") unhookAllForms();
      // Refresh overlay
      closeOverlay();
      toggleOverlay();
    };

    // Toggle switches
    overlay.querySelectorAll("[data-toggle-idx]").forEach(toggle => {
      toggle.onchange = () => {
        const idx = parseInt(toggle.dataset.toggleIdx);
        const form = forms[idx];
        if (toggle.checked) {
          hookForm(form.element);
          form.hooked = true;
        } else {
          unhookForm(form.element);
          form.hooked = false;
        }
      };
    });

    // Highlight buttons
    overlay.querySelectorAll("[data-highlight-idx]").forEach(btn => {
      btn.onclick = () => {
        const idx = parseInt(btn.dataset.highlightIdx);
        highlightForm(forms[idx].element);
      };
    });

    // Escape to close
    const escHandler = (e) => {
      if (e.key === "Escape") { closeOverlay(); document.removeEventListener("keydown", escHandler); }
    };
    document.addEventListener("keydown", escHandler);
  }

  function closeOverlay() {
    const overlay = document.getElementById("integra-overlay");
    if (overlay) {
      overlay.classList.add("integra-overlay-closing");
      setTimeout(() => overlay.remove(), 200);
    }
    overlayVisible = false;
    // Remove any highlights
    document.querySelectorAll(".integra-highlighted").forEach(el => {
      el.classList.remove("integra-highlighted");
    });
  }

  function highlightForm(form) {
    // Remove existing highlights
    document.querySelectorAll(".integra-highlighted").forEach(el => {
      el.classList.remove("integra-highlighted");
    });

    form.classList.add("integra-highlighted");
    form.scrollIntoView({ behavior: "smooth", block: "center" });

    // Remove after 3s
    setTimeout(() => form.classList.remove("integra-highlighted"), 3000);
  }

  // ═══════════════════════════════════════════════════════════
  // Auto mode — hook all forms
  // ═══════════════════════════════════════════════════════════
  function hookAllForms() {
    const forms = discoverForms();
    forms.forEach(f => hookForm(f.element));
  }

  function unhookAllForms() {
    const forms = discoverForms();
    forms.forEach(f => unhookForm(f.element));
  }

  // ═══════════════════════════════════════════════════════════
  // Attest focused form — Ctrl+Shift+S
  // ═══════════════════════════════════════════════════════════
  function attestFocusedForm() {
    // Find the form that contains the currently focused element
    const active = document.activeElement;
    const form = active?.closest("form");

    if (!form) {
      showToast("No form is focused. Click inside a form first.");
      return;
    }

    if (!hookedForms.has(form)) {
      hookForm(form);
      showToast(`Armed: "${form.getAttribute("name") || form.id || "form"}". Submit to attest.`);
    } else {
      showToast("This form is already armed for attestation.");
    }
  }

  // ═══════════════════════════════════════════════════════════
  // Toast notifications
  // ═══════════════════════════════════════════════════════════
  function showToast(message) {
    const existing = document.getElementById("integra-toast");
    if (existing) existing.remove();

    const toast = document.createElement("div");
    toast.id = "integra-toast";
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("integra-toast-hide");
      setTimeout(() => toast.remove(), 300);
    }, 2500);
  }

  // ═══════════════════════════════════════════════════════════
  // Persistence
  // ═══════════════════════════════════════════════════════════
  async function saveConfig() {
    try {
      await chrome.storage.sync.set({ integraConfig: config });
    } catch (e) { /* noop */ }
  }

  // ═══════════════════════════════════════════════════════════
  // Helpers
  // ═══════════════════════════════════════════════════════════
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  // ═══════════════════════════════════════════════════════════
  // Message handler — commands from background/popup
  // ═══════════════════════════════════════════════════════════
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg.action) {
      case "toggle-overlay":
        toggleOverlay();
        break;
      case "attest-focused":
        attestFocusedForm();
        break;
      case "set-mode":
        config.mode = msg.mode;
        config.domainRules[location.hostname] = msg.mode;
        saveConfig();
        if (msg.mode === "auto") hookAllForms();
        else if (msg.mode === "off") unhookAllForms();
        break;
      case "get-status":
        const forms = discoverForms();
        const authSession = typeof IntegraAuth !== "undefined" ? IntegraAuth.getSession() : null;
        sendResponse({
          domain: location.hostname,
          mode: config.mode,
          total: forms.length,
          armed: forms.filter(f => f.hooked).length,
          forms: forms.map(f => ({ label: f.label, method: f.method, fields: f.fieldCount, armed: f.hooked })),
          auth: authSession ? { signedIn: IntegraAuth.isSignedIn(), method: authSession.method, displayName: authSession.displayName } : null,
        });
        return true; // async response
      case "auth-changed":
        // Auth state changed from popup — log it
        if (typeof IntegraAuth !== "undefined") {
          const sess = IntegraAuth.getSession();
          if (sess && IntegraAuth.isSignedIn()) {
            console.log("[Integra] Auth updated:", sess.displayName, sess.algorithm);
          } else {
            console.log("[Integra] Signed out — attestations will be unsigned");
          }
        }
        break;
    }
  });

  // ═══════════════════════════════════════════════════════════
  // MutationObserver — catch dynamically added forms (SPAs)
  // ═══════════════════════════════════════════════════════════
  const observer = new MutationObserver((mutations) => {
    if (config.mode !== "auto") return;

    let hasNewForms = false;
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeName === "FORM" || (node.querySelector && node.querySelector("form"))) {
          hasNewForms = true;
          break;
        }
      }
      if (hasNewForms) break;
    }

    if (hasNewForms) {
      // Debounce
      clearTimeout(observer._timer);
      observer._timer = setTimeout(() => hookAllForms(), 300);
    }
  });

  // ═══════════════════════════════════════════════════════════
  // Init
  // ═══════════════════════════════════════════════════════════
  async function init() {
    await loadConfig();

    if (config.mode === "auto") {
      hookAllForms();
    }

    // Watch for dynamic forms
    observer.observe(document.body, { childList: true, subtree: true });
  }

  init();
})();
