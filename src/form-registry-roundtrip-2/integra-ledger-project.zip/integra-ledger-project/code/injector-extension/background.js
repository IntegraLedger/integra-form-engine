/**
 * Integra Attest — Background Service Worker
 * Handles keyboard shortcuts + icon badge updates
 */

// Handle keyboard commands
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  chrome.tabs.sendMessage(tab.id, { action: command });
});

// Listen for status updates from content script
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === "badge-update" && sender.tab?.id) {
    const { hookedCount } = msg;
    if (hookedCount > 0) {
      chrome.action.setBadgeText({ text: String(hookedCount), tabId: sender.tab.id });
      chrome.action.setBadgeBackgroundColor({ color: "#2563eb", tabId: sender.tab.id });
    } else {
      chrome.action.setBadgeText({ text: "", tabId: sender.tab.id });
    }
  }
});

// On install, set default config
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get("integraConfig", (data) => {
    if (!data.integraConfig) {
      chrome.storage.sync.set({
        integraConfig: {
          mode: "manual",
          apiKey: "",
          siteId: "",
          showBadge: true,
          showReceipt: true,
          domainRules: {},
          excludeSelectors: [
            "[data-integra-skip]",
            ".integra-skip",
            'form[action*="search"]',
            'form[role="search"]',
          ],
        }
      });
    }
  });
});
