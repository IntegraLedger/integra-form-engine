/**
 * Ask Integra - Trust Badge & Attestation Logger
 * 
 * Usage: <script src="https://cdn.integraledger.com/badge.js" data-integra-id="SITE_ID"></script>
 * 
 * - Renders a "Trusted by Integra" badge
 * - Logs page views and attestation API calls back to Integra
 * - Sites get a dashboard showing verification activity
 */
(function () {
  "use strict";

  const API_BASE = "https://api.integraledger.com/v1";

  // Get config from the script tag itself
  const scriptTag = document.currentScript;
  const siteId = scriptTag?.getAttribute("data-integra-id") || "unknown";
  const position = scriptTag?.getAttribute("data-position") || "bottom-right";
  const theme = scriptTag?.getAttribute("data-theme") || "light";

  // ─── Logger ────────────────────────────────────────────────────
  function log(event, data) {
    const payload = {
      siteId,
      event,
      url: window.location.href,
      referrer: document.referrer,
      timestamp: new Date().toISOString(),
      ...data,
    };

    // Use sendBeacon for reliability (survives page unload)
    if (navigator.sendBeacon) {
      navigator.sendBeacon(
        `${API_BASE}/badge/log`,
        new Blob([JSON.stringify(payload)], { type: "application/json" })
      );
    } else {
      fetch(`${API_BASE}/badge/log`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
        keepalive: true,
      }).catch(() => {});
    }
  }

  // ─── Badge Rendering ───────────────────────────────────────────
  function renderBadge() {
    const posStyles = {
      "bottom-right": "bottom:20px;right:20px;",
      "bottom-left": "bottom:20px;left:20px;",
      "top-right": "top:20px;right:20px;",
      "top-left": "top:20px;left:20px;",
    };

    const isDark = theme === "dark";
    const bg = isDark ? "#1a1a2e" : "#ffffff";
    const text = isDark ? "#e0e0e0" : "#1a1a2e";
    const accent = "#2563eb";
    const border = isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.08)";

    const badge = document.createElement("a");
    badge.id = "integra-badge";
    badge.href = `https://verify.integraledger.com/site/${siteId}`;
    badge.target = "_blank";
    badge.rel = "noopener";
    badge.title = "Verified by Integra Ledger - Click to verify";

    badge.style.cssText = `
      position:fixed;${posStyles[position] || posStyles["bottom-right"]}
      z-index:99999;
      display:flex;align-items:center;gap:8px;
      padding:8px 14px;
      background:${bg};
      color:${text};
      border:1px solid ${border};
      border-radius:8px;
      box-shadow:0 2px 8px rgba(0,0,0,0.1);
      font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
      font-size:12px;font-weight:500;
      text-decoration:none;
      cursor:pointer;
      transition:box-shadow 0.2s,transform 0.2s;
    `;

    badge.onmouseenter = () => {
      badge.style.boxShadow = "0 4px 16px rgba(37,99,235,0.2)";
      badge.style.transform = "translateY(-1px)";
    };
    badge.onmouseleave = () => {
      badge.style.boxShadow = "0 2px 8px rgba(0,0,0,0.1)";
      badge.style.transform = "translateY(0)";
    };

    // Shield icon SVG
    const icon = `<svg width="18" height="20" viewBox="0 0 18 20" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M9 0L0 3.5V9.5C0 14.75 3.84 19.64 9 20C14.16 19.64 18 14.75 18 9.5V3.5L9 0Z" fill="${accent}" fill-opacity="0.12"/>
      <path d="M9 1L1 4.1V9.5C1 14.2 4.41 18.67 9 19C13.59 18.67 17 14.2 17 9.5V4.1L9 1Z" stroke="${accent}" stroke-width="1.2"/>
      <path d="M6 10L8 12L12 7.5" stroke="${accent}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;

    badge.innerHTML = `
      ${icon}
      <span style="display:flex;flex-direction:column;line-height:1.3;">
        <span style="font-size:10px;opacity:0.6;text-transform:uppercase;letter-spacing:0.5px;">Trusted by</span>
        <span style="font-weight:700;color:${accent};font-size:13px;">Integra</span>
      </span>
    `;

    badge.addEventListener("click", () => {
      log("badge_click");
    });

    document.body.appendChild(badge);
  }

  // ─── Init ──────────────────────────────────────────────────────
  function init() {
    log("page_view", {
      title: document.title,
      userAgent: navigator.userAgent,
    });

    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", renderBadge);
    } else {
      renderBadge();
    }

    // Log when user leaves
    window.addEventListener("beforeunload", () => {
      log("page_exit", {
        timeOnPage: Math.round(performance.now() / 1000),
      });
    });
  }

  init();
})();
