/**
 * Integra Response Interceptor
 *
 * The core idea: monkey-patch fetch() and XMLHttpRequest so that
 * ANY form POST on the page gets its response captured transparently.
 *
 * We don't need to intercept the submit event at all — we intercept
 * at the network layer. Whatever the form does (fetch, XHR, native POST),
 * we see what went out AND what came back.
 *
 * For each intercepted POST:
 *   1. Capture the request body → hash it
 *   2. Let it go through to the server normally
 *   3. Capture the response: status, headers, body
 *   4. Extract server proof: signatures, record IDs, tokens
 *   5. Build a binding: SHA-256(requestHash | responseHash | serverProof)
 *   6. Store the round-trip record
 */

(function () {
  "use strict";

  // ═══════════════════════════════════════════════════════════
  // Storage for captured round-trips
  // ═══════════════════════════════════════════════════════════
  const captures = [];
  let onCapture = null; // callback(capture) set by consumer

  // ═══════════════════════════════════════════════════════════
  // Crypto
  // ═══════════════════════════════════════════════════════════
  async function sha256(data) {
    const buf = typeof data === "string" ? new TextEncoder().encode(data) : data;
    const hash = await crypto.subtle.digest("SHA-256", buf);
    return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, "0")).join("");
  }

  async function hmacSha256(key, message) {
    const keyData = new TextEncoder().encode(key);
    const msgData = new TextEncoder().encode(message);
    const k = await crypto.subtle.importKey("raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign("HMAC", k, msgData);
    return Array.from(new Uint8Array(sig), b => b.toString(16).padStart(2, "0")).join("");
  }

  function genSalt() {
    const b = new Uint8Array(16);
    crypto.getRandomValues(b);
    return Array.from(b, x => x.toString(16).padStart(2, "0")).join("");
  }

  // ═══════════════════════════════════════════════════════════
  // Parse request body into fields (handles multiple formats)
  // ═══════════════════════════════════════════════════════════
  function parseRequestBody(body, contentType) {
    const fields = {};

    if (!body) return fields;

    // URLSearchParams (most common form encoding)
    if (typeof body === "string" || body instanceof URLSearchParams) {
      const params = new URLSearchParams(body.toString());
      for (const [k, v] of params) fields[k] = v;
      return fields;
    }

    // FormData
    if (body instanceof FormData) {
      for (const [k, v] of body.entries()) {
        if (typeof v === "string") fields[k] = v;
        else fields[k] = `[File: ${v.name}, ${v.size} bytes]`;
      }
      return fields;
    }

    // JSON
    if (typeof body === "object") {
      try {
        const flat = flattenObject(body);
        for (const [k, v] of Object.entries(flat)) fields[k] = String(v);
      } catch {}
      return fields;
    }

    // String that might be JSON
    if (typeof body === "string") {
      try {
        const parsed = JSON.parse(body);
        const flat = flattenObject(parsed);
        for (const [k, v] of Object.entries(flat)) fields[k] = String(v);
      } catch {
        // Treat as raw body
        fields["_body"] = body;
      }
    }

    return fields;
  }

  function flattenObject(obj, prefix = "") {
    const result = {};
    for (const [k, v] of Object.entries(obj)) {
      const key = prefix ? `${prefix}.${k}` : k;
      if (v && typeof v === "object" && !Array.isArray(v)) {
        Object.assign(result, flattenObject(v, key));
      } else {
        result[key] = v;
      }
    }
    return result;
  }

  // ═══════════════════════════════════════════════════════════
  // Extract server proof from response
  // ═══════════════════════════════════════════════════════════
  function extractServerProof(headers, body, status) {
    const proof = {
      // What the server says about itself
      server: null,
      requestId: null,
      // Server's own signature of the response (if any)
      signature: null,
      signatureHeader: null,
      // Server-generated record/confirmation
      recordId: null,
      recordIdField: null,
      // Content integrity
      etag: null,
      digest: null,
      // Timestamps
      serverDate: null,
      // Infrastructure trace
      traceId: null,
      // All captured headers
      rawHeaders: {},
    };

    // ── Signature headers (proves server signed the response) ──
    const sigHeaders = [
      "x-signature", "x-hmac-signature", "signature",
      "x-hub-signature-256",    // GitHub webhooks
      "x-integra-sig",
      "x-shopify-hmac-sha256",  // Shopify
      "stripe-signature",       // Stripe
    ];
    for (const h of sigHeaders) {
      const v = getHeader(headers, h);
      if (v) { proof.signature = v; proof.signatureHeader = h; break; }
    }

    // ── Content digest (RFC 3230 / RFC 9530) ──
    proof.digest = getHeader(headers, "digest") || getHeader(headers, "content-digest");

    // ── Request tracking ──
    proof.requestId =
      getHeader(headers, "x-request-id") ||
      getHeader(headers, "x-correlation-id") ||
      getHeader(headers, "x-amzn-requestid") ||
      getHeader(headers, "x-amzn-trace-id") ||
      getHeader(headers, "cf-ray") ||
      getHeader(headers, "x-vercel-id") ||
      getHeader(headers, "x-cloud-trace-context");

    // ── Server info ──
    proof.server = getHeader(headers, "server");
    proof.serverDate = getHeader(headers, "date");
    proof.etag = getHeader(headers, "etag");
    proof.traceId =
      getHeader(headers, "x-trace-id") ||
      getHeader(headers, "x-b3-traceid") ||
      getHeader(headers, "traceparent");

    // ── All interesting headers ──
    const interesting = [
      "server", "date", "etag", "last-modified",
      "x-request-id", "x-correlation-id", "x-amzn-requestid", "cf-ray",
      "x-vercel-id", "x-powered-by", "content-type", "content-length",
      "x-ratelimit-remaining", "x-ratelimit-limit",
      "strict-transport-security", "x-content-type-options",
      "set-cookie", // presence of (not value)
      ...sigHeaders, "digest", "content-digest",
    ];
    for (const h of interesting) {
      const v = getHeader(headers, h);
      if (v) {
        // Redact cookie values but note their presence
        proof.rawHeaders[h] = h === "set-cookie" ? "[present]" : v;
      }
    }

    // ── Extract record ID from response body ──
    if (body && typeof body === "string" && body.length < 500000) {
      try {
        const json = JSON.parse(body);
        const idFields = [
          "id", "_id", "Id", "ID",
          "recordId", "record_id",
          "ticketId", "ticket_id",
          "caseId", "case_id",
          "referenceId", "reference_id",
          "confirmationNumber", "confirmation_number",
          "orderId", "order_id",
          "transactionId", "transaction_id",
          "envelopeId", "envelope_id",  // DocuSign
          "uid", "uuid",
          "key", "ref",
          "number",                      // Zendesk ticket.number
        ];

        // Check top level
        for (const f of idFields) {
          if (json[f] != null) {
            proof.recordId = String(json[f]);
            proof.recordIdField = f;
            break;
          }
        }

        // Check nested: data.id, result.id, ticket.id, etc.
        if (!proof.recordId) {
          const nests = ["data", "result", "ticket", "record", "order", "response", "envelope", "case"];
          for (const n of nests) {
            if (json[n] && typeof json[n] === "object") {
              for (const f of idFields) {
                if (json[n][f] != null) {
                  proof.recordId = String(json[n][f]);
                  proof.recordIdField = `${n}.${f}`;
                  break;
                }
              }
              if (proof.recordId) break;
            }
          }
        }

        // Check if the response itself contains a URL (common in REST APIs)
        if (!proof.recordId && json.url) {
          proof.recordId = json.url;
          proof.recordIdField = "url";
        }

      } catch {
        // Not JSON — try HTML patterns
        const patterns = [
          /(?:confirmation|reference|ticket|case|order|record)\s*(?:#|number|id|:)\s*[:=]?\s*["']?([A-Z0-9][\w-]{3,30})/i,
          /data-(?:ticket|record|case|order)-id=["']([^"']+)/i,
        ];
        for (const p of patterns) {
          const m = body.match(p);
          if (m) { proof.recordId = m[1]; proof.recordIdField = "html-pattern"; break; }
        }
      }
    }

    return proof;
  }

  function getHeader(headers, name) {
    if (headers instanceof Headers) return headers.get(name);
    if (typeof headers === "object") {
      // Case-insensitive lookup
      for (const [k, v] of Object.entries(headers)) {
        if (k.toLowerCase() === name.toLowerCase()) return v;
      }
    }
    return null;
  }

  // ═══════════════════════════════════════════════════════════
  // Build attestation record from captured round-trip
  // ═══════════════════════════════════════════════════════════
  async function buildAttestation(url, method, requestBody, contentType, responseStatus, responseHeaders, responseBody) {
    const timestamp = new Date().toISOString();
    const salt = genSalt();

    // ── Hash request fields ──
    const fields = parseRequestBody(requestBody, contentType);
    const fieldHashes = {};
    for (const name of Object.keys(fields).sort()) {
      fieldHashes[name] = await hmacSha256(salt, `${name}:${fields[name]}`);
    }

    // Merkle root of field hashes
    let leaves = Object.values(fieldHashes);
    while (leaves.length > 1) {
      const next = [];
      for (let i = 0; i < leaves.length; i += 2) {
        const l = leaves[i], r = i + 1 < leaves.length ? leaves[i + 1] : leaves[i];
        next.push(await sha256(l + r));
      }
      leaves = next;
    }
    const merkleRoot = leaves[0] || await sha256("empty");
    const requestHash = await sha256(JSON.stringify(fields, Object.keys(fields).sort()));

    // ── Hash response ──
    const responseHash = responseBody ? await sha256(responseBody) : null;

    // ── Extract server proof ──
    const serverProof = extractServerProof(responseHeaders, responseBody, responseStatus);
    const headersHash = await sha256(JSON.stringify(serverProof.rawHeaders, Object.keys(serverProof.rawHeaders).sort()));

    // ── Bind: the round-trip hash ties everything together ──
    const bindingComponents = [
      requestHash,                            // what was sent
      responseHash || "empty",                // what came back (body)
      headersHash,                            // what headers came back
      String(responseStatus),                 // HTTP status
      serverProof.signature || "unsigned",    // server's signature
      serverProof.requestId || "no-req-id",   // server's request tracking
      serverProof.recordId || "no-record-id", // server-generated ID
      serverProof.digest || "no-digest",      // content digest
      timestamp,
    ];
    const roundTripHash = await sha256(bindingComponents.join("|"));

    const record = {
      integraId: "ig_" + roundTripHash.slice(0, 12),
      timestamp,

      request: {
        url,
        method,
        contentType: contentType || "unknown",
        fields,
        fieldHashes,
        fieldCount: Object.keys(fields).length,
        merkleRoot,
        requestHash,
        salt,
      },

      response: {
        status: responseStatus,
        bodyHash: responseHash,
        headersHash,
        bodyLength: responseBody ? responseBody.length : 0,
      },

      serverProof: {
        signature: serverProof.signature,
        signatureHeader: serverProof.signatureHeader,
        digest: serverProof.digest,
        requestId: serverProof.requestId,
        recordId: serverProof.recordId,
        recordIdField: serverProof.recordIdField,
        etag: serverProof.etag,
        server: serverProof.server,
        serverDate: serverProof.serverDate,
        traceId: serverProof.traceId,
        capturedHeaders: serverProof.rawHeaders,
      },

      binding: {
        roundTripHash,
        components: bindingComponents,
        formula: "SHA-256( requestHash | responseBodyHash | responseHeadersHash | httpStatus | serverSig | requestId | recordId | contentDigest | timestamp )",
      },
    };

    captures.push(record);
    if (onCapture) onCapture(record);

    console.log("[Integra] Round-trip captured:", record.integraId, {
      sent: Object.keys(fields).length + " fields",
      status: responseStatus,
      serverSig: serverProof.signature ? "✅ " + serverProof.signatureHeader : "❌ unsigned",
      serverId: serverProof.recordId || "none",
      requestId: serverProof.requestId || "none",
      roundTrip: roundTripHash.slice(0, 20) + "...",
    });

    return record;
  }

  // ═══════════════════════════════════════════════════════════
  // MONKEY-PATCH: fetch()
  // ═══════════════════════════════════════════════════════════
  const originalFetch = window.fetch;

  window.fetch = async function (input, init = {}) {
    const url = typeof input === "string" ? input : input.url;
    const method = (init.method || (input.method) || "GET").toUpperCase();

    // Only intercept POST/PUT/PATCH (form submissions)
    if (!["POST", "PUT", "PATCH"].includes(method)) {
      return originalFetch.call(this, input, init);
    }

    // Capture request body
    let requestBody = init.body;
    let bodyString = null;
    const contentType = getHeader(init.headers || {}, "content-type")
      || (input.headers ? getHeader(input.headers, "content-type") : null);

    if (requestBody instanceof FormData) {
      bodyString = new URLSearchParams(requestBody).toString();
    } else if (requestBody instanceof URLSearchParams) {
      bodyString = requestBody.toString();
    } else if (typeof requestBody === "string") {
      bodyString = requestBody;
    } else if (requestBody instanceof ArrayBuffer || requestBody instanceof Uint8Array) {
      try { bodyString = new TextDecoder().decode(requestBody); } catch {}
    }

    // Let the actual request through
    const response = await originalFetch.call(this, input, init);

    // Clone response so we can read it without consuming
    const clone = response.clone();

    // Read response body asynchronously (don't block the caller)
    clone.text().then(async (responseText) => {
      try {
        await buildAttestation(
          url, method,
          bodyString || requestBody,
          contentType,
          response.status,
          response.headers,
          responseText
        );
      } catch (e) {
        console.warn("[Integra] Failed to build attestation:", e);
      }
    });

    // Return original response immediately — caller is unaffected
    return response;
  };

  // ═══════════════════════════════════════════════════════════
  // MONKEY-PATCH: XMLHttpRequest
  // ═══════════════════════════════════════════════════════════
  const XHROpen = XMLHttpRequest.prototype.open;
  const XHRSend = XMLHttpRequest.prototype.send;
  const XHRSetHeader = XMLHttpRequest.prototype.setRequestHeader;

  XMLHttpRequest.prototype.open = function (method, url, ...args) {
    this._integra = { method: method.toUpperCase(), url, headers: {} };
    return XHROpen.call(this, method, url, ...args);
  };

  XMLHttpRequest.prototype.setRequestHeader = function (name, value) {
    if (this._integra) this._integra.headers[name] = value;
    return XHRSetHeader.call(this, name, value);
  };

  XMLHttpRequest.prototype.send = function (body) {
    const info = this._integra;

    if (info && ["POST", "PUT", "PATCH"].includes(info.method)) {
      const xhr = this;

      xhr.addEventListener("load", async function () {
        try {
          // Build a Headers-like object from getAllResponseHeaders
          const rawHeaders = {};
          const headerStr = xhr.getAllResponseHeaders();
          if (headerStr) {
            headerStr.trim().split(/\r?\n/).forEach(line => {
              const idx = line.indexOf(":");
              if (idx > 0) {
                rawHeaders[line.slice(0, idx).trim().toLowerCase()] = line.slice(idx + 1).trim();
              }
            });
          }

          await buildAttestation(
            info.url,
            info.method,
            body,
            info.headers["Content-Type"] || info.headers["content-type"],
            xhr.status,
            rawHeaders,
            xhr.responseText
          );
        } catch (e) {
          console.warn("[Integra] XHR attestation failed:", e);
        }
      });
    }

    return XHRSend.call(this, body);
  };

  // ═══════════════════════════════════════════════════════════
  // INTERCEPT: Native form submissions (no JS — full page POST)
  //
  // For forms that do a traditional submit (page navigates),
  // we use a beacon to fire off the request attestation before
  // the page unloads. The response attestation happens on the
  // next page load if the extension is still active.
  // ═══════════════════════════════════════════════════════════
  document.addEventListener("submit", function (e) {
    const form = e.target;
    if (!form || form.tagName !== "FORM") return;

    const method = (form.method || "GET").toUpperCase();
    if (method === "GET") return;

    // Collect form data
    const fields = {};
    for (const [k, v] of new FormData(form).entries()) {
      if (typeof v === "string") fields[k] = v;
    }

    // We can't intercept the response for a native form POST
    // (page navigates away). But we CAN attest what was sent
    // and store it. The landing page can then be compared.
    const record = {
      type: "native-submit",
      url: form.action || location.href,
      method,
      fields,
      fieldCount: Object.keys(fields).length,
      timestamp: new Date().toISOString(),
      origin: location.origin,
    };

    // Store in sessionStorage so we can pick it up on next page
    try {
      const pending = JSON.parse(sessionStorage.getItem("integra_pending") || "[]");
      pending.push(record);
      sessionStorage.setItem("integra_pending", JSON.stringify(pending));
    } catch {}

    // Also send beacon to Integra API
    try {
      navigator.sendBeacon(
        "https://api.integraledger.com/v1/attest/pre-submit",
        JSON.stringify(record)
      );
    } catch {}

  }, true);

  // On page load, check if we have a pending native submit to complete
  if (sessionStorage.getItem("integra_pending")) {
    try {
      const pending = JSON.parse(sessionStorage.getItem("integra_pending"));
      if (pending.length > 0) {
        // We're on the response page now — capture it
        const lastSubmit = pending[pending.length - 1];
        console.log("[Integra] Found pending native form submit:", lastSubmit);

        // Hash the current page as the "response"
        sha256(document.documentElement.outerHTML).then(pageHash => {
          lastSubmit.responsePageHash = pageHash;
          lastSubmit.responseUrl = location.href;
          lastSubmit.responseTimestamp = new Date().toISOString();

          // Notify
          if (onCapture) onCapture({ ...lastSubmit, type: "native-roundtrip" });
          console.log("[Integra] Native round-trip completed. Response page hash:", pageHash.slice(0, 24) + "...");
        });

        sessionStorage.removeItem("integra_pending");
      }
    } catch {}
  }

  // ═══════════════════════════════════════════════════════════
  // Public API
  // ═══════════════════════════════════════════════════════════
  window.IntegraInterceptor = {
    // Get all captured round-trips
    getCaptures: () => [...captures],

    // Get latest capture
    getLatest: () => captures[captures.length - 1] || null,

    // Set callback for new captures
    onCapture: (fn) => { onCapture = fn; },

    // Search captures by server record ID
    findByRecordId: (id) => captures.find(c => c.serverProof?.recordId === id),

    // Search captures by URL
    findByUrl: (url) => captures.filter(c => c.request.url.includes(url)),

    // Export all captures as JSON
    exportJSON: () => JSON.stringify(captures, null, 2),

    // Verify a field against a capture
    verifyField: async (captureIdx, fieldName, fieldValue) => {
      const cap = captures[captureIdx];
      if (!cap) return { error: "Capture not found" };
      const expected = cap.request.fieldHashes[fieldName];
      if (!expected) return { error: "Field not in capture" };
      const actual = await hmacSha256(cap.request.salt, `${fieldName}:${fieldValue}`);
      return { match: actual === expected, expected, actual };
    },
  };

  console.log("[Integra] 🔐 Response interceptor active. All POST/PUT/PATCH requests will be captured.");
  console.log("[Integra] Access via: IntegraInterceptor.getCaptures(), .getLatest(), .onCapture(fn)");

})();
