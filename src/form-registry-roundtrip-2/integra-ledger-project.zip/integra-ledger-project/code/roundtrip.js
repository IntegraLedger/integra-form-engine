/**
 * Integra Ledger — Round-Trip Attestation
 *
 * Captures the FULL cycle:
 *   REQUEST  → hash form fields, capture headers sent
 *   RESPONSE → capture status, headers, body hash, server signature
 *   BIND     → tie request attestation to response attestation
 *
 * The receipt includes:
 *   - requestHash:  SHA-256 of canonicalized form data
 *   - responseHash: SHA-256 of response body
 *   - serverSig:    server's signature header if present
 *   - roundTripHash: SHA-256(requestHash + responseHash + timestamp)
 *   - responseHeaders: captured server headers (Date, X-Request-Id, ETag, etc.)
 *
 * This proves: "This exact data was sent, and THIS exact response came back."
 */

(function () {
  "use strict";

  const INTEGRA_API = "https://api.integraledger.com";

  // ═══════════════════════════════════════════════════════════
  // Crypto helpers
  // ═══════════════════════════════════════════════════════════
  async function sha256(data) {
    const buf = typeof data === "string"
      ? new TextEncoder().encode(data)
      : data;
    const hash = await crypto.subtle.digest("SHA-256", buf);
    return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, "0")).join("");
  }

  async function hmacSha256(key, message) {
    const keyData = new TextEncoder().encode(key);
    const msgData = new TextEncoder().encode(message);
    const cryptoKey = await crypto.subtle.importKey(
      "raw", keyData, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
    );
    const sig = await crypto.subtle.sign("HMAC", cryptoKey, msgData);
    return Array.from(new Uint8Array(sig), b => b.toString(16).padStart(2, "0")).join("");
  }

  function generateSalt() {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
  }

  function canonicalize(obj) {
    return JSON.stringify(obj, Object.keys(obj).sort());
  }

  // ═══════════════════════════════════════════════════════════
  // Interesting response headers to capture
  // ═══════════════════════════════════════════════════════════
  const CAPTURE_HEADERS = [
    // Server identification
    "server",
    "x-powered-by",
    // Request tracking
    "x-request-id",
    "x-correlation-id",
    "x-trace-id",
    "x-amzn-requestid",        // AWS
    "cf-ray",                   // Cloudflare
    "x-vercel-id",              // Vercel
    "x-cloud-trace-context",    // GCP
    // Caching / versioning
    "etag",
    "last-modified",
    // Timestamps
    "date",
    // Security
    "x-content-type-options",
    "strict-transport-security",
    "content-security-policy",
    // Signature (if server signs responses)
    "x-signature",
    "x-hmac-signature",
    "digest",                   // RFC 3230 instance digest
    "signature",                // HTTP Signatures
    "x-integra-sig",            // Our own
    // Rate / quota
    "x-ratelimit-remaining",
    // Content
    "content-type",
    "content-length",
  ];

  // ═══════════════════════════════════════════════════════════
  // RoundTripAttestation class
  // ═══════════════════════════════════════════════════════════
  class RoundTripAttestation {

    /**
     * Attest a form submission with full round-trip capture.
     *
     * @param {HTMLFormElement} form - The form element
     * @param {Object} options
     * @param {string} options.mode - "fetch" (intercept & replay via fetch) or "xhr" (XMLHttpRequest)
     * @param {string} options.apiKey - Integra API key
     * @param {string} options.siteId - Registered site ID
     * @param {Function} options.onAttestation - callback(receipt) after full round-trip
     * @param {Function} options.onError - callback(error)
     * @param {boolean} options.includeResponseBody - hash the response body (default true)
     * @param {boolean} options.captureRedirects - follow and capture redirects (default false)
     * @returns {Promise<RoundTripReceipt>}
     */
    static async attestFormSubmit(form, options = {}) {
      const {
        apiKey = "",
        siteId = "",
        onAttestation = null,
        onError = null,
        includeResponseBody = true,
        captureRedirects = false,
      } = options;

      const startTime = performance.now();
      const timestamp = new Date().toISOString();

      // ─── Phase 1: Capture REQUEST ──────────────────────
      const formData = new FormData(form);
      const fields = {};
      const fieldOrder = [];
      for (const [k, v] of formData.entries()) {
        if (typeof v === "string") {
          fields[k] = v;
          fieldOrder.push(k);
        }
      }

      // Salt + hash each field
      const salt = generateSalt();
      const fieldHashes = {};
      for (const name of Object.keys(fields).sort()) {
        fieldHashes[name] = await hmacSha256(salt, `${name}:${fields[name]}`);
      }

      // Merkle root
      let leaves = Object.values(fieldHashes);
      while (leaves.length > 1) {
        const next = [];
        for (let i = 0; i < leaves.length; i += 2) {
          const left = leaves[i];
          const right = i + 1 < leaves.length ? leaves[i + 1] : leaves[i];
          next.push(await sha256(left + right));
        }
        leaves = next;
      }
      const merkleRoot = leaves[0] || await sha256("empty");
      const requestHash = await sha256(canonicalize(fields));

      const requestAttestation = {
        requestHash,
        merkleRoot,
        fieldHashes,
        fieldCount: Object.keys(fields).length,
        fieldOrder,
        salt,
        method: (form.method || "POST").toUpperCase(),
        action: form.action || location.href,
        timestamp,
        origin: location.origin,
        path: location.pathname,
        ssl: location.protocol === "https:",
      };

      // ─── Phase 2: Submit form via fetch & capture RESPONSE ─
      let response, responseBody, responseText;
      try {
        const method = requestAttestation.method;
        const action = requestAttestation.action;

        const fetchOptions = {
          method,
          redirect: captureRedirects ? "follow" : "follow",
          credentials: "same-origin",
        };

        // Build body based on form enctype
        const enctype = form.enctype || "application/x-www-form-urlencoded";
        if (method !== "GET") {
          if (enctype === "multipart/form-data") {
            fetchOptions.body = formData;
          } else if (enctype === "application/json") {
            fetchOptions.headers = { "Content-Type": "application/json" };
            fetchOptions.body = JSON.stringify(fields);
          } else {
            fetchOptions.headers = { "Content-Type": "application/x-www-form-urlencoded" };
            fetchOptions.body = new URLSearchParams(formData).toString();
          }
        }

        response = await fetch(action, fetchOptions);

        // Clone to read body without consuming
        const clone = response.clone();
        responseBody = await clone.arrayBuffer();
        try { responseText = new TextDecoder().decode(responseBody); } catch { responseText = null; }

      } catch (err) {
        const error = { phase: "submit", message: err.message, timestamp };
        if (onError) onError(error);
        throw err;
      }

      // ─── Phase 3: Capture RESPONSE attestation ─────────
      const responseHash = includeResponseBody
        ? await sha256(new Uint8Array(responseBody))
        : null;

      // Extract interesting headers
      const capturedHeaders = {};
      for (const name of CAPTURE_HEADERS) {
        const val = response.headers.get(name);
        if (val) capturedHeaders[name] = val;
      }

      // Look for server signature specifically
      const serverSignature =
        response.headers.get("x-signature") ||
        response.headers.get("x-hmac-signature") ||
        response.headers.get("signature") ||
        response.headers.get("digest") ||
        response.headers.get("x-integra-sig") ||
        null;

      // Try to extract server-generated ID from response
      let serverRecordId = null;
      if (responseText) {
        try {
          const json = JSON.parse(responseText);
          // Common patterns for server-generated IDs
          serverRecordId =
            json.id || json._id || json.recordId || json.record_id ||
            json.ticketId || json.ticket_id || json.caseId || json.case_id ||
            json.referenceId || json.reference_id || json.confirmationNumber ||
            json.data?.id || json.result?.id ||
            null;
          if (serverRecordId) serverRecordId = String(serverRecordId);
        } catch {
          // Not JSON — try to find ID patterns in HTML
          const match = responseText.match(
            /(?:confirmation|reference|ticket|case|record|order)[^"]*?[#:\s]+([A-Z0-9-]{4,30})/i
          );
          if (match) serverRecordId = match[1];
        }
      }

      // Hash of captured headers (proves which headers were present)
      const headersHash = await sha256(canonicalize(capturedHeaders));

      const responseAttestation = {
        status: response.status,
        statusText: response.statusText,
        responseHash,
        headersHash,
        capturedHeaders,
        serverSignature,
        serverRecordId,
        redirected: response.redirected,
        finalUrl: response.url,
        responseTimestamp: new Date().toISOString(),
        latencyMs: Math.round(performance.now() - startTime),
      };

      // ─── Phase 4: BIND request + response ──────────────
      // The round-trip hash proves these two things are linked
      const bindingInput = [
        requestAttestation.requestHash,
        responseAttestation.responseHash || "no-body",
        responseAttestation.headersHash,
        String(responseAttestation.status),
        responseAttestation.serverSignature || "no-sig",
        requestAttestation.timestamp,
        responseAttestation.responseTimestamp,
      ].join("|");

      const roundTripHash = await sha256(bindingInput);

      // ─── Phase 5: Call Integra API with full record ────
      let integraReceipt;
      try {
        const apiPayload = {
          type: "round-trip",
          request: {
            hash: requestAttestation.requestHash,
            merkleRoot: requestAttestation.merkleRoot,
            fieldCount: requestAttestation.fieldCount,
            salt: requestAttestation.salt,
            method: requestAttestation.method,
            action: requestAttestation.action,
            origin: requestAttestation.origin,
            timestamp: requestAttestation.timestamp,
            ssl: requestAttestation.ssl,
          },
          response: {
            hash: responseAttestation.responseHash,
            headersHash: responseAttestation.headersHash,
            status: responseAttestation.status,
            serverSignature: responseAttestation.serverSignature,
            serverRecordId: responseAttestation.serverRecordId,
            latencyMs: responseAttestation.latencyMs,
            timestamp: responseAttestation.responseTimestamp,
          },
          roundTripHash,
          fieldHashes: requestAttestation.fieldHashes,
        };

        const resp = await fetch(`${INTEGRA_API}/v1/attest/roundtrip`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(apiKey ? { Authorization: `Bearer ${apiKey}` } : {}),
          },
          body: JSON.stringify(apiPayload),
        });
        if (resp.ok) integraReceipt = await resp.json();
      } catch (e) {
        // API not reachable — create local receipt
      }

      if (!integraReceipt) {
        integraReceipt = {
          integraId: "ig_" + roundTripHash.slice(0, 12),
          status: "local",
          timestamp: requestAttestation.timestamp,
          verifyUrl: `https://verify.integraledger.com/a/ig_${roundTripHash.slice(0, 12)}`,
        };
      }

      // ─── Assemble complete receipt ─────────────────────
      const receipt = {
        // Integra attestation
        integraId: integraReceipt.integraId,
        verifyUrl: integraReceipt.verifyUrl,
        attestationStatus: integraReceipt.status || "attested",

        // Request side
        request: {
          hash: requestAttestation.requestHash,
          merkleRoot: requestAttestation.merkleRoot,
          fieldCount: requestAttestation.fieldCount,
          fieldHashes: requestAttestation.fieldHashes,
          salt: requestAttestation.salt,
          method: requestAttestation.method,
          action: requestAttestation.action,
          timestamp: requestAttestation.timestamp,
        },

        // Response side
        response: {
          status: responseAttestation.status,
          statusText: responseAttestation.statusText,
          hash: responseAttestation.responseHash,
          headersHash: responseAttestation.headersHash,
          headers: responseAttestation.capturedHeaders,
          serverSignature: responseAttestation.serverSignature,
          serverRecordId: responseAttestation.serverRecordId,
          redirected: responseAttestation.redirected,
          finalUrl: responseAttestation.finalUrl,
          latencyMs: responseAttestation.latencyMs,
          timestamp: responseAttestation.responseTimestamp,
        },

        // Binding proof
        roundTripHash,

        // For convenience
        origin: requestAttestation.origin,
        ssl: requestAttestation.ssl,
      };

      if (onAttestation) onAttestation(receipt);
      return { receipt, response, responseText };
    }
  }

  // ═══════════════════════════════════════════════════════════
  // Receipt Display — shows the round-trip proof
  // ═══════════════════════════════════════════════════════════
  function renderReceipt(container, receipt) {
    const r = receipt;
    const resp = r.response;
    const req = r.request;

    const sigDisplay = resp.serverSignature
      ? `<div class="rt-row">
           <span class="rt-label">Server Signature</span>
           <span class="rt-value rt-mono rt-sig">${truncate(resp.serverSignature, 40)}</span>
         </div>`
      : `<div class="rt-row">
           <span class="rt-label">Server Signature</span>
           <span class="rt-value rt-warn">None (server doesn't sign responses)</span>
         </div>`;

    const serverIdDisplay = resp.serverRecordId
      ? `<div class="rt-row">
           <span class="rt-label">Server Record ID</span>
           <span class="rt-value rt-mono">${resp.serverRecordId}</span>
         </div>`
      : "";

    const headersList = Object.entries(resp.headers || {})
      .map(([k, v]) => `<div class="rt-header-row"><span class="rt-hdr-name">${k}:</span> <span class="rt-hdr-val">${truncate(v, 50)}</span></div>`)
      .join("");

    container.innerHTML = `
      <div class="rt-receipt">
        <div class="rt-receipt-title">
          <span class="rt-icon">🔐</span>
          Round-Trip Attestation
          <span class="rt-status ${r.attestationStatus}">${r.attestationStatus === "local" ? "⚠ Local" : "✅ Verified"}</span>
        </div>

        <div class="rt-section">
          <div class="rt-section-title">→ Request</div>
          <div class="rt-row">
            <span class="rt-label">Content Hash</span>
            <span class="rt-value rt-mono">${truncate(req.hash, 32)}</span>
          </div>
          <div class="rt-row">
            <span class="rt-label">Merkle Root</span>
            <span class="rt-value rt-mono">${truncate(req.merkleRoot, 32)}</span>
          </div>
          <div class="rt-row">
            <span class="rt-label">Fields</span>
            <span class="rt-value">${req.fieldCount} hashed · ${req.method} ${truncate(req.action, 30)}</span>
          </div>
          <div class="rt-row">
            <span class="rt-label">Sent</span>
            <span class="rt-value">${new Date(req.timestamp).toLocaleString()}</span>
          </div>
        </div>

        <div class="rt-section">
          <div class="rt-section-title">← Response</div>
          <div class="rt-row">
            <span class="rt-label">Status</span>
            <span class="rt-value rt-status-code">${resp.status} ${resp.statusText}</span>
          </div>
          <div class="rt-row">
            <span class="rt-label">Body Hash</span>
            <span class="rt-value rt-mono">${resp.hash ? truncate(resp.hash, 32) : "N/A"}</span>
          </div>
          <div class="rt-row">
            <span class="rt-label">Headers Hash</span>
            <span class="rt-value rt-mono">${truncate(resp.headersHash, 32)}</span>
          </div>
          ${sigDisplay}
          ${serverIdDisplay}
          <div class="rt-row">
            <span class="rt-label">Latency</span>
            <span class="rt-value">${resp.latencyMs}ms${resp.redirected ? " (redirected → " + truncate(resp.finalUrl, 30) + ")" : ""}</span>
          </div>
        </div>

        <div class="rt-section rt-binding">
          <div class="rt-section-title">⛓ Binding Proof</div>
          <div class="rt-row">
            <span class="rt-label">Round-Trip Hash</span>
            <span class="rt-value rt-mono rt-highlight">${truncate(r.roundTripHash, 40)}</span>
          </div>
          <div class="rt-row">
            <span class="rt-label">Integra ID</span>
            <span class="rt-value rt-mono">${r.integraId}</span>
          </div>
          <div class="rt-explain">
            SHA-256( requestHash | responseHash | headersHash | status | serverSig | timestamps )
          </div>
        </div>

        ${headersList ? `
        <details class="rt-headers-details">
          <summary class="rt-headers-summary">Captured Response Headers (${Object.keys(resp.headers).length})</summary>
          <div class="rt-headers-list">${headersList}</div>
        </details>` : ""}

        <div class="rt-footer">
          <a href="${r.verifyUrl}" target="_blank" class="rt-verify-link">Verify attestation →</a>
        </div>
      </div>
    `;
  }

  function truncate(str, len) {
    if (!str) return "—";
    str = String(str);
    return str.length > len ? str.slice(0, len) + "..." : str;
  }

  // ═══════════════════════════════════════════════════════════
  // CSS for receipt (injected once)
  // ═══════════════════════════════════════════════════════════
  function injectStyles() {
    if (document.getElementById("integra-rt-styles")) return;
    const style = document.createElement("style");
    style.id = "integra-rt-styles";
    style.textContent = `
      .rt-receipt {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        background: #1a1a2e; border: 1px solid #2a2a4a; border-radius: 14px;
        overflow: hidden; margin: 16px 0; color: #e0e0e0;
        box-shadow: 0 4px 24px rgba(0,0,0,0.3);
      }
      .rt-receipt-title {
        display: flex; align-items: center; gap: 8px;
        padding: 14px 18px; font-size: 14px; font-weight: 700; color: #fff;
        background: linear-gradient(135deg, #1e1e38, #1a1a2e);
        border-bottom: 1px solid #2a2a4a;
      }
      .rt-icon { font-size: 18px; }
      .rt-status { margin-left: auto; font-size: 11px; font-weight: 600; padding: 3px 10px; border-radius: 12px; }
      .rt-status.local { background: #f59e0b20; color: #f59e0b; }
      .rt-status.attested { background: #22c55e20; color: #34d399; }
      .rt-section { padding: 12px 18px; border-bottom: 1px solid #1a1a3a; }
      .rt-section:last-of-type { border-bottom: none; }
      .rt-section-title { font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; color: #93c5fd; margin-bottom: 8px; }
      .rt-binding .rt-section-title { color: #f59e0b; }
      .rt-row { display: flex; justify-content: space-between; align-items: baseline; padding: 3px 0; gap: 12px; }
      .rt-label { font-size: 11px; color: #666; font-weight: 600; white-space: nowrap; min-width: 100px; }
      .rt-value { font-size: 12px; color: #e0e0e0; text-align: right; word-break: break-all; }
      .rt-mono { font-family: 'SF Mono', Monaco, Consolas, monospace; font-size: 10px; color: #93c5fd; }
      .rt-sig { color: #34d399; }
      .rt-highlight { color: #f59e0b; font-weight: 600; }
      .rt-warn { color: #666; font-style: italic; font-size: 11px; }
      .rt-status-code { font-weight: 700; color: #34d399; }
      .rt-explain { font-size: 10px; color: #555; font-family: 'SF Mono', Monaco, monospace; margin-top: 6px; padding: 6px 10px; background: #12122a; border-radius: 6px; }
      .rt-headers-details { padding: 0 18px 12px; }
      .rt-headers-summary { font-size: 11px; color: #555; cursor: pointer; padding: 6px 0; }
      .rt-headers-summary:hover { color: #93c5fd; }
      .rt-headers-list { padding: 8px 12px; background: #12122a; border-radius: 8px; margin-top: 6px; }
      .rt-header-row { font-size: 10px; font-family: 'SF Mono', Monaco, monospace; padding: 2px 0; }
      .rt-hdr-name { color: #666; }
      .rt-hdr-val { color: #93c5fd; }
      .rt-footer { padding: 10px 18px; border-top: 1px solid #2a2a4a; text-align: center; }
      .rt-verify-link { color: #2563eb; font-size: 12px; text-decoration: none; font-weight: 600; }
      .rt-verify-link:hover { text-decoration: underline; }
    `;
    document.head.appendChild(style);
  }

  // ═══════════════════════════════════════════════════════════
  // Export
  // ═══════════════════════════════════════════════════════════
  injectStyles();

  window.IntegraRoundTrip = {
    attestFormSubmit: RoundTripAttestation.attestFormSubmit,
    renderReceipt,
    sha256,
    hmacSha256,
    generateSalt,
  };

})();
