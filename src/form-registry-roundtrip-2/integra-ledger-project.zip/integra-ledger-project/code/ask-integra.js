/**
 * Ask Integra - Document Attestation Verification Widget
 * Include via: <script src="https://cdn.integraledger.com/ask-integra.js"></script>
 *
 * Scans page for Integra attestation meta tags and data attributes,
 * renders a verification badge, and exposes attestation data to
 * AI assistants (Gemini, etc.) and the Integra API.
 */
(function () {
  "use strict";

  const INTEGRA_API_BASE =
    window.INTEGRA_API_BASE || "https://api.integraledger.com/v1";
  const INTEGRA_CDN_BASE =
    window.INTEGRA_CDN_BASE || "https://cdn.integraledger.com";

  // ─── Configuration ───────────────────────────────────────────────
  const DEFAULT_CONFIG = {
    position: "bottom-right", // bottom-right, bottom-left, top-right, top-left
    theme: "light", // light, dark, auto
    size: "standard", // compact, standard
    autoVerify: true, // auto-verify attestations on load
    exposeToAI: true, // inject structured data for AI browsers
    showBadge: true, // show floating badge
    apiKey: null, // optional public API key for rate limiting
  };

  // ─── Tag Scanner ─────────────────────────────────────────────────
  // Reads attestation data from multiple sources on the page
  class TagScanner {
    constructor() {
      this.attestations = [];
    }

    scan() {
      this.attestations = [];
      this._scanMetaTags();
      this._scanDataAttributes();
      this._scanJsonLd();
      this._scanLinkTags();
      return this.attestations;
    }

    // <meta name="integra:attestation" content="0x..." />
    // <meta name="integra:document-hash" content="sha256:..." />
    // <meta name="integra:attester" content="0x..." />
    // <meta name="integra:schema" content="rwa-deed" />
    // <meta name="integra:chain" content="ethereum" />
    // <meta name="integra:timestamp" content="2025-01-15T..." />
    _scanMetaTags() {
      const metaTags = document.querySelectorAll('meta[name^="integra:"]');
      const grouped = {};

      metaTags.forEach((tag) => {
        const key = tag.getAttribute("name").replace("integra:", "");
        const value = tag.getAttribute("content");
        // Group by attestation index if present (integra:attestation:0, integra:attestation:1)
        const match = key.match(/^(.+?)(?::(\d+))?$/);
        const field = match[1];
        const index = match[2] || "0";

        if (!grouped[index]) grouped[index] = {};
        grouped[index][field] = value;
      });

      Object.values(grouped).forEach((data) => {
        if (data.attestation || data["document-hash"]) {
          this.attestations.push({
            source: "meta",
            uid: data.attestation || null,
            documentHash: data["document-hash"] || null,
            attester: data.attester || null,
            schema: data.schema || null,
            chain: data.chain || "ethereum",
            timestamp: data.timestamp || null,
            recipient: data.recipient || null,
            rawData: data,
          });
        }
      });
    }

    // <div data-integra-attestation="0x..." data-integra-hash="sha256:...">
    _scanDataAttributes() {
      const elements = document.querySelectorAll("[data-integra-attestation]");
      elements.forEach((el) => {
        this.attestations.push({
          source: "data-attribute",
          uid: el.dataset.integraAttestation,
          documentHash: el.dataset.integraHash || null,
          attester: el.dataset.integraAttester || null,
          schema: el.dataset.integraSchema || null,
          chain: el.dataset.integraChain || "ethereum",
          timestamp: el.dataset.integraTimestamp || null,
          recipient: el.dataset.integraRecipient || null,
          element: el,
          rawData: { ...el.dataset },
        });
      });
    }

    // <script type="application/ld+json">{ "@type": "IntegraAttestation", ... }</script>
    _scanJsonLd() {
      const scripts = document.querySelectorAll(
        'script[type="application/ld+json"]'
      );
      scripts.forEach((script) => {
        try {
          const data = JSON.parse(script.textContent);
          const items = Array.isArray(data) ? data : [data];
          items.forEach((item) => {
            if (
              item["@type"] === "IntegraAttestation" ||
              item["@type"] === "BlockchainAttestation"
            ) {
              this.attestations.push({
                source: "json-ld",
                uid: item.attestationUid || item.uid || null,
                documentHash: item.documentHash || item.contentHash || null,
                attester: item.attester || null,
                schema: item.schemaId || item.schema || null,
                chain: item.blockchain || item.chain || "ethereum",
                timestamp: item.dateCreated || item.timestamp || null,
                recipient: item.recipient || null,
                rawData: item,
              });
            }
          });
        } catch (e) {
          // skip invalid JSON-LD
        }
      });
    }

    // <link rel="integra-attestation" href="https://api.integraledger.com/attestation/0x..." />
    _scanLinkTags() {
      const links = document.querySelectorAll(
        'link[rel="integra-attestation"]'
      );
      links.forEach((link) => {
        const href = link.getAttribute("href");
        const uidMatch = href?.match(/attestation\/(.+?)(?:\?|$)/);
        this.attestations.push({
          source: "link",
          uid: uidMatch ? uidMatch[1] : null,
          verifyUrl: href,
          documentHash: link.dataset?.hash || null,
          chain: link.dataset?.chain || "ethereum",
          rawData: { href },
        });
      });
    }
  }

  // ─── AI Exposure Layer ───────────────────────────────────────────
  // Makes attestation data discoverable by AI browsers (Gemini, etc.)
  class AIExposure {
    inject(attestations, verificationResults) {
      this._injectStructuredData(attestations, verificationResults);
      this._injectSemanticHTML(attestations, verificationResults);
      this._exposeWindowAPI(attestations, verificationResults);
    }

    _injectStructuredData(attestations, results) {
      // Remove any existing
      document
        .querySelectorAll('script[data-integra-ai="true"]')
        .forEach((el) => el.remove());

      const ldJson = {
        "@context": "https://schema.integraledger.com/v1",
        "@type": "DocumentVerification",
        verificationProvider: "Integra Ledger",
        verificationDate: new Date().toISOString(),
        attestations: attestations.map((a, i) => ({
          "@type": "BlockchainAttestation",
          attestationUid: a.uid,
          documentHash: a.documentHash,
          blockchain: a.chain,
          attester: a.attester,
          schema: a.schema,
          verificationStatus: results?.[i]?.verified ? "Verified" : "Pending",
          verificationDetails: results?.[i] || null,
        })),
      };

      const script = document.createElement("script");
      script.type = "application/ld+json";
      script.dataset.integraAi = "true";
      script.textContent = JSON.stringify(ldJson);
      document.head.appendChild(script);
    }

    _injectSemanticHTML(attestations, results) {
      // Add a hidden but accessible element AI browsers can read
      let container = document.getElementById("integra-ai-context");
      if (!container) {
        container = document.createElement("div");
        container.id = "integra-ai-context";
        container.setAttribute("role", "complementary");
        container.setAttribute("aria-label", "Document Attestation Information");
        container.style.cssText =
          "position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0);";
        document.body.appendChild(container);
      }

      const verified = results?.filter((r) => r?.verified).length || 0;
      const total = attestations.length;

      container.innerHTML = `
        <h2>Ask Integra - Document Verification</h2>
        <p>This document contains ${total} blockchain attestation(s). ${verified} of ${total} have been verified on-chain.</p>
        ${attestations
          .map(
            (a, i) => `
          <article data-attestation-index="${i}">
            <h3>Attestation ${a.uid ? a.uid.slice(0, 10) + "..." : "Unknown"}</h3>
            <dl>
              <dt>Status</dt><dd>${results?.[i]?.verified ? "✅ Verified" : "⏳ Pending Verification"}</dd>
              <dt>Document Hash</dt><dd>${a.documentHash || "Not provided"}</dd>
              <dt>Blockchain</dt><dd>${a.chain}</dd>
              <dt>Attester</dt><dd>${a.attester || "Not provided"}</dd>
              <dt>Schema</dt><dd>${a.schema || "Not provided"}</dd>
            </dl>
          </article>
        `
          )
          .join("")}
        <p>For verification details, visit <a href="https://verify.integraledger.com">Integra Ledger Verification Portal</a> or query the Ask Integra API.</p>
      `;
    }

    _exposeWindowAPI(attestations, results) {
      // Expose a clean API on window for AI agents or other scripts
      window.IntegraAttestation = {
        version: "1.0.0",
        attestations: attestations.map((a, i) => ({
          uid: a.uid,
          documentHash: a.documentHash,
          attester: a.attester,
          schema: a.schema,
          chain: a.chain,
          timestamp: a.timestamp,
          verified: results?.[i]?.verified || false,
          verificationDetails: results?.[i] || null,
        })),
        count: attestations.length,
        verifiedCount: results?.filter((r) => r?.verified).length || 0,
        verify: async (uid) => window._integra?.verifyAttestation(uid),
        getAll: () => window.IntegraAttestation.attestations,
        toJSON: () => JSON.stringify(window.IntegraAttestation.attestations),
      };
    }
  }

  // ─── API Client ──────────────────────────────────────────────────
  class IntegraAPI {
    constructor(apiKey) {
      this.apiKey = apiKey;
    }

    async verify(attestation) {
      try {
        const headers = { "Content-Type": "application/json" };
        if (this.apiKey) headers["X-Integra-Key"] = this.apiKey;

        const response = await fetch(`${INTEGRA_API_BASE}/verify`, {
          method: "POST",
          headers,
          body: JSON.stringify({
            uid: attestation.uid,
            documentHash: attestation.documentHash,
            chain: attestation.chain,
          }),
        });

        if (!response.ok) throw new Error(`API error: ${response.status}`);
        return await response.json();
      } catch (err) {
        console.warn("[Ask Integra] Verification failed:", err.message);
        return { verified: false, error: err.message };
      }
    }

    async verifyBatch(attestations) {
      // Parallel verification
      return Promise.all(attestations.map((a) => this.verify(a)));
    }

    async submitAttestation(data) {
      const headers = { "Content-Type": "application/json" };
      if (this.apiKey) headers["X-Integra-Key"] = this.apiKey;

      const response = await fetch(`${INTEGRA_API_BASE}/attest`, {
        method: "POST",
        headers,
        body: JSON.stringify(data),
      });

      if (!response.ok) throw new Error(`API error: ${response.status}`);
      return await response.json();
    }
  }

  // ─── Badge Widget ────────────────────────────────────────────────
  class BadgeWidget {
    constructor(config) {
      this.config = config;
      this.container = null;
      this.panel = null;
      this.isOpen = false;
    }

    render(attestations, results) {
      this._injectStyles();
      this._createBadge(attestations, results);
      this._createPanel(attestations, results);
    }

    update(attestations, results) {
      if (this.container) this.container.remove();
      if (this.panel) this.panel.remove();
      this.render(attestations, results);
    }

    _injectStyles() {
      if (document.getElementById("integra-badge-styles")) return;

      const style = document.createElement("style");
      style.id = "integra-badge-styles";
      style.textContent = `
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

        #integra-badge {
          position: fixed;
          z-index: 99999;
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        #integra-badge.bottom-right { bottom: 20px; right: 20px; }
        #integra-badge.bottom-left { bottom: 20px; left: 20px; }
        #integra-badge.top-right { top: 20px; right: 20px; }
        #integra-badge.top-left { top: 20px; left: 20px; }

        .integra-badge-btn {
          display: flex;
          align-items: center;
          gap: 8px;
          padding