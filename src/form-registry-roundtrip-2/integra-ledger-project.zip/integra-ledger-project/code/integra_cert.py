"""
Integra Ledger — Attestation Certificate PDF Generator

Generates a professional certificate PDF containing:
- Form field values with per-field salted hashes
- Merkle root of all field hashes
- QR code encoding the verification deep link
- SSL certificate info
- Blockchain attestation reference
- Verification instructions

Usage:
    from integra_cert import generate_certificate

    cert_path = generate_certificate(
        integra_id="ig_a1b2c3d4e5f6",
        form_label="Client Intake Form",
        form_fields={"firstName": "Jane", "lastName": "Doe", "email": "jane@example.com"},
        origin="https://acmelegal.com",
        ssl_issuer="Let's Encrypt R3",
        ssl_fingerprint="AB:CD:EF:12:34:56:78:90",
        content_hash="abc123...",
        timestamp="2026-02-12T14:30:00Z",
    )
"""

import hashlib
import hmac
import json
import os
import secrets
import io
from datetime import datetime

import qrcode
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch, mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    Image, HRFlowable, KeepTogether
)
from reportlab.graphics.shapes import Drawing, Rect, Line, String, Circle
from reportlab.graphics import renderPDF


# ─── Crypto: salt + hash individual fields ────────────────────────
def generate_salt():
    """Generate a 16-byte random salt."""
    return secrets.token_hex(16)


def hash_field(field_name, field_value, salt):
    """
    Salt + hash a single field value.
    Uses HMAC-SHA256 with the salt as key and "field_name:field_value" as message.
    This way the same value in different fields produces different hashes.
    """
    message = f"{field_name}:{field_value}".encode("utf-8")
    return hmac.new(salt.encode("utf-8"), message, hashlib.sha256).hexdigest()


def hash_all_fields(fields: dict, salt: str = None):
    """
    Hash every field individually and compute a Merkle root.

    Returns:
        {
            "salt": "hex...",
            "fieldHashes": {"firstName": "abc...", "lastName": "def...", ...},
            "merkleRoot": "xyz...",
            "fieldCount": 3
        }
    """
    if salt is None:
        salt = generate_salt()

    field_hashes = {}
    for name, value in sorted(fields.items()):
        field_hashes[name] = hash_field(name, str(value), salt)

    # Simple Merkle root: iteratively hash pairs
    leaves = [bytes.fromhex(h) for h in field_hashes.values()]
    if not leaves:
        merkle_root = hashlib.sha256(b"empty").hexdigest()
    else:
        level = leaves
        while len(level) > 1:
            next_level = []
            for i in range(0, len(level), 2):
                left = level[i]
                right = level[i + 1] if i + 1 < len(level) else level[i]
                next_level.append(hashlib.sha256(left + right).digest())
            level = next_level
        merkle_root = level[0].hex()

    return {
        "salt": salt,
        "fieldHashes": field_hashes,
        "merkleRoot": merkle_root,
        "fieldCount": len(fields),
    }


# ─── QR Code generation ──────────────────────────────────────────
def generate_qr_image(data, size=180):
    """Generate a QR code as a PIL Image."""
    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=8,
        border=2,
    )
    qr.add_data(data)
    qr.make(fit=True)

    img = qr.make_image(fill_color="#1a1a2e", back_color="white")
    img = img.resize((size, size))
    return img


def qr_to_reportlab_image(qr_data, width=1.8 * inch):
    """Convert QR data string to a ReportLab Image flowable."""
    img = generate_qr_image(qr_data)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    buf.seek(0)
    return Image(buf, width=width, height=width)


# ─── Shield logo as Drawing ──────────────────────────────────────
def make_shield_drawing(size=60):
    d = Drawing(size, size)
    # Background circle
    d.add(Circle(size / 2, size / 2, size / 2 - 2, fillColor=colors.HexColor("#2563eb"),
                 fillOpacity=0.1, strokeColor=colors.HexColor("#2563eb"), strokeWidth=1.5))
    # Checkmark approximation
    d.add(String(size / 2 - 8, size / 2 - 8, "✓",
                 fontSize=28, fillColor=colors.HexColor("#2563eb"),
                 fontName="Helvetica-Bold"))
    return d


# ─── PDF Certificate Generator ────────────────────────────────────
def generate_certificate(
    integra_id: str,
    form_label: str,
    form_fields: dict,
    origin: str,
    ssl_issuer: str = "Unknown",
    ssl_fingerprint: str = "N/A",
    content_hash: str = None,
    timestamp: str = None,
    output_path: str = None,
    include_field_values: bool = True,
    salt: str = None,
) -> str:
    """
    Generate an Integra Ledger attestation certificate PDF.

    Args:
        integra_id: The attestation ID (e.g., "ig_abc123")
        form_label: Human-readable form name
        form_fields: Dict of field_name -> field_value
        origin: The origin URL
        ssl_issuer: SSL certificate issuer
        ssl_fingerprint: SSL cert fingerprint
        content_hash: Overall content hash (computed if None)
        timestamp: ISO timestamp (now if None)
        output_path: Where to save PDF (auto-generated if None)
        include_field_values: Whether to show actual values (True) or just hashes
        salt: Salt for field hashing (auto-generated if None)

    Returns:
        Path to the generated PDF file.
    """

    if timestamp is None:
        timestamp = datetime.utcnow().isoformat() + "Z"

    # Hash all fields
    hash_result = hash_all_fields(form_fields, salt)

    if content_hash is None:
        canonical = json.dumps(form_fields, sort_keys=True)
        content_hash = hashlib.sha256(canonical.encode()).hexdigest()

    if output_path is None:
        output_path = f"integra-cert-{integra_id}.pdf"

    # QR data
    qr_data = (
        f"integra://attest/{integra_id}"
        f"?h={content_hash[:16]}"
        f"&m={hash_result['merkleRoot'][:16]}"
        f"&s={origin.split('//')[1] if '//' in origin else origin}"
    )
    verify_url = f"https://verify.integraledger.com/a/{integra_id}"

    # ─── Styles ───────────────────────────────────────────
    styles = getSampleStyleSheet()

    style_title = ParagraphStyle(
        "CertTitle", parent=styles["Title"],
        fontSize=22, leading=26, textColor=colors.HexColor("#1a1a2e"),
        spaceAfter=4, alignment=TA_CENTER, fontName="Helvetica-Bold",
    )
    style_subtitle = ParagraphStyle(
        "CertSubtitle", parent=styles["Normal"],
        fontSize=11, leading=14, textColor=colors.HexColor("#666"),
        alignment=TA_CENTER, spaceAfter=20,
    )
    style_section = ParagraphStyle(
        "SectionHead", parent=styles["Heading2"],
        fontSize=13, leading=16, textColor=colors.HexColor("#2563eb"),
        spaceBefore=16, spaceAfter=8, fontName="Helvetica-Bold",
    )
    style_body = ParagraphStyle(
        "Body", parent=styles["Normal"],
        fontSize=10, leading=14, textColor=colors.HexColor("#333"),
    )
    style_mono = ParagraphStyle(
        "Mono", parent=styles["Normal"],
        fontSize=8.5, leading=12, textColor=colors.HexColor("#1a1a2e"),
        fontName="Courier",
    )
    style_small = ParagraphStyle(
        "Small", parent=styles["Normal"],
        fontSize=8, leading=10, textColor=colors.HexColor("#999"),
        alignment=TA_CENTER,
    )

    # ─── Build document ───────────────────────────────────
    doc = SimpleDocTemplate(
        output_path,
        pagesize=letter,
        topMargin=0.6 * inch,
        bottomMargin=0.6 * inch,
        leftMargin=0.75 * inch,
        rightMargin=0.75 * inch,
    )

    story = []
    W = doc.width

    # ─── Header bar ───────────────────────────────────────
    header_data = [[
        Paragraph('<font color="#2563eb"><b>INTEGRA LEDGER</b></font>', styles["Normal"]),
        Paragraph(f'<font color="#999" size="9">Attestation Certificate</font>', styles["Normal"]),
    ]]
    header_table = Table(header_data, colWidths=[W * 0.5, W * 0.5])
    header_table.setStyle(TableStyle([
        ("ALIGN", (0, 0), (0, 0), "LEFT"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(header_table)

    # Blue line
    story.append(HRFlowable(
        width="100%", thickness=2,
        color=colors.HexColor("#2563eb"), spaceAfter=16,
    ))

    # ─── Title ────────────────────────────────────────────
    story.append(Paragraph("Attestation Certificate", style_title))
    story.append(Paragraph(
        f"This document certifies the blockchain attestation of a form submission.",
        style_subtitle
    ))

    # ─── Main info + QR code side by side ─────────────────
    qr_img = qr_to_reportlab_image(qr_data, width=1.6 * inch)

    info_lines = f"""
    <b>Integra ID:</b> {integra_id}<br/>
    <b>Form:</b> {form_label}<br/>
    <b>Origin:</b> {origin}<br/>
    <b>Timestamp:</b> {timestamp}<br/>
    <b>SSL Issuer:</b> {ssl_issuer}<br/>
    <b>SSL Fingerprint:</b> <font face="Courier" size="8">{ssl_fingerprint[:32]}...</font>
    """
    info_para = Paragraph(info_lines, style_body)

    main_data = [[info_para, qr_img]]
    main_table = Table(main_data, colWidths=[W - 1.8 * inch, 1.8 * inch])
    main_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("RIGHTPADDING", (0, 0), (0, 0), 12),
        ("ALIGN", (1, 0), (1, 0), "CENTER"),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#ddd")),
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#f8fafc")),
        ("TOPPADDING", (0, 0), (-1, -1), 12),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 12),
        ("LEFTPADDING", (0, 0), (0, 0), 12),
        ("ROUNDEDCORNERS", [6, 6, 6, 6]),
    ]))
    story.append(main_table)

    # ─── Content Hash ─────────────────────────────────────
    story.append(Paragraph("Content Hash", style_section))
    story.append(Paragraph(
        f'<font face="Courier" size="9" color="#1a1a2e">{content_hash}</font>',
        style_body
    ))
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        "SHA-256 hash of the canonicalized form data. This hash is anchored on-chain.",
        style_small
    ))

    # ─── Merkle Root ──────────────────────────────────────
    story.append(Paragraph("Merkle Root", style_section))
    story.append(Paragraph(
        f'<font face="Courier" size="9" color="#1a1a2e">{hash_result["merkleRoot"]}</font>',
        style_body
    ))
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        f'Computed from {hash_result["fieldCount"]} individually salted field hashes. '
        f'Salt: <font face="Courier" size="7">{hash_result["salt"][:16]}...</font>',
        style_small
    ))

    # ─── Field-Level Hashes ───────────────────────────────
    story.append(Paragraph("Field-Level Attestation", style_section))
    story.append(Paragraph(
        "Each field is individually salted and hashed using HMAC-SHA256. "
        "This enables selective disclosure — any single field can be verified "
        "without revealing the others.",
        style_body
    ))
    story.append(Spacer(1, 8))

    # Table header
    if include_field_values:
        col_widths = [W * 0.18, W * 0.30, W * 0.52]
        field_table_data = [["Field", "Value", "HMAC-SHA256 Hash"]]
    else:
        col_widths = [W * 0.25, W * 0.75]
        field_table_data = [["Field", "HMAC-SHA256 Hash"]]

    for name in sorted(form_fields.keys()):
        value = str(form_fields[name])
        h = hash_result["fieldHashes"][name]

        if include_field_values:
            display_value = value if len(value) <= 40 else value[:37] + "..."
            field_table_data.append([
                Paragraph(f'<b>{name}</b>', style_body),
                Paragraph(f'<font size="9">{display_value}</font>', style_body),
                Paragraph(f'<font face="Courier" size="7">{h}</font>', style_body),
            ])
        else:
            field_table_data.append([
                Paragraph(f'<b>{name}</b>', style_body),
                Paragraph(f'<font face="Courier" size="7">{h}</font>', style_body),
            ])

    field_table = Table(field_table_data, colWidths=col_widths, repeatRows=1)
    field_table.setStyle(TableStyle([
        # Header row
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2563eb")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 9),
        ("BOTTOMPADDING", (0, 0), (-1, 0), 8),
        ("TOPPADDING", (0, 0), (-1, 0), 8),
        # Data rows
        ("FONTSIZE", (0, 1), (-1, -1), 9),
        ("TOPPADDING", (0, 1), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 1), (-1, -1), 5),
        # Alternating row colors
        *[("BACKGROUND", (0, i), (-1, i), colors.HexColor("#f8fafc"))
          for i in range(2, len(field_table_data), 2)],
        # Grid
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#e0e0e0")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(field_table)

    # ─── Verification Instructions ────────────────────────
    story.append(Spacer(1, 16))
    story.append(Paragraph("Verification", style_section))

    verify_text = f"""
    <b>To verify this attestation:</b><br/><br/>
    1. <b>Scan the QR code</b> with the Integra mobile app to instantly verify.<br/>
    2. <b>Visit</b> <font color="#2563eb"><link href="{verify_url}">{verify_url}</link></font><br/>
    3. <b>API:</b> <font face="Courier" size="8">GET /v1/verify/{integra_id}</font><br/><br/>
    <b>To verify a single field:</b><br/>
    Recompute <font face="Courier" size="8">HMAC-SHA256(salt, "field_name:field_value")</font>
    and compare against the hash above. The salt is stored with the attestation record.
    """
    story.append(Paragraph(verify_text, style_body))

    # ─── Footer ───────────────────────────────────────────
    story.append(Spacer(1, 24))
    story.append(HRFlowable(
        width="100%", thickness=0.5,
        color=colors.HexColor("#ddd"), spaceAfter=8,
    ))

    footer_data = [[
        Paragraph(
            '<font size="8" color="#999">'
            'This certificate was generated by Integra Ledger. '
            'The attestation is anchored on Ethereum via EAS (Ethereum Attestation Service). '
            'Neither this document nor its contents constitute legal advice.'
            '</font>',
            style_body
        ),
        Paragraph(
            f'<font size="8" color="#999">'
            f'Generated: {datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")}<br/>'
            f'<font face="Courier" size="7">{integra_id}</font>'
            f'</font>',
            ParagraphStyle("FootR", parent=style_body, alignment=TA_RIGHT)
        ),
    ]]
    footer_table = Table(footer_data, colWidths=[W * 0.65, W * 0.35])
    footer_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(footer_table)

    # ─── Build PDF ────────────────────────────────────────
    doc.build(story)
    return output_path


# ─── CLI / Demo ───────────────────────────────────────────────────
if __name__ == "__main__":
    # Demo: generate a sample certificate
    fields = {
        "firstName": "Jane",
        "lastName": "Doe",
        "email": "jane@example.com",
        "company": "Acme Legal LLC",
        "caseType": "RWA Tokenization",
        "description": "Tokenize commercial real estate portfolio with blockchain attestation for all transfer documents.",
    }

    # Hash fields
    result = hash_all_fields(fields)
    print(f"Salt:        {result['salt']}")
    print(f"Merkle Root: {result['merkleRoot']}")
    print(f"Fields:      {result['fieldCount']}")
    print()
    for name, h in sorted(result["fieldHashes"].items()):
        print(f"  {name:15s} → {h}")
    print()

    # Generate overall content hash
    content_hash = hashlib.sha256(
        json.dumps(fields, sort_keys=True).encode()
    ).hexdigest()

    # Generate certificate
    path = generate_certificate(
        integra_id="ig_a1b2c3d4e5f6",
        form_label="Client Intake Form",
        form_fields=fields,
        origin="https://acmelegal.com",
        ssl_issuer="Let's Encrypt R3",
        ssl_fingerprint="AB:CD:EF:12:34:56:78:90:AB:CD:EF:12:34:56:78:90",
        content_hash=content_hash,
        timestamp="2026-02-12T14:30:00Z",
        output_path="integra-attestation-certificate.pdf",
        include_field_values=True,
        salt=result["salt"],
    )
    print(f"Certificate: {path}")

    # Also generate a redacted version (hashes only, no values)
    path2 = generate_certificate(
        integra_id="ig_a1b2c3d4e5f6",
        form_label="Client Intake Form",
        form_fields=fields,
        origin="https://acmelegal.com",
        ssl_issuer="Let's Encrypt R3",
        ssl_fingerprint="AB:CD:EF:12:34:56:78:90:AB:CD:EF:12:34:56:78:90",
        content_hash=content_hash,
        timestamp="2026-02-12T14:30:00Z",
        output_path="integra-attestation-certificate-redacted.pdf",
        include_field_values=False,
        salt=result["salt"],
    )
    print(f"Redacted:    {path2}")
